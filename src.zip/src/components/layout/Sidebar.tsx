
import React from 'react';
import { useAuth, UserRole } from '@/contexts/AuthContext';
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarHeader,
  SidebarFooter,
} from '@/components/ui/sidebar';
import { 
  Heart, 
  Calendar, 
  Users, 
  FileText, 
  UserCheck, 
  Settings, 
  MessageSquare,
  BarChart3,
  Stethoscope,
  Activity,
  CreditCard,
  LogOut,
  Pill,
  ClipboardList
} from 'lucide-react';
import { Button } from '@/components/ui/button';

interface SidebarProps {
  currentPage: string;
  onPageChange: (page: string) => void;
}

const AppSidebar: React.FC<SidebarProps> = ({ currentPage, onPageChange }) => {
  const { user, logout } = useAuth();

  const getMenuItems = (role: UserRole) => {
    const baseItems = [
      { 
        id: 'dashboard', 
        title: 'Tableau de bord', 
        icon: BarChart3, 
        roles: ['patient', 'doctor', 'nurse', 'admin'] 
      },
      { 
        id: 'appointments', 
        title: 'Rendez-vous', 
        icon: Calendar, 
        roles: ['patient', 'doctor', 'nurse', 'admin'] 
      },
      { 
        id: 'messages', 
        title: 'Messages', 
        icon: MessageSquare, 
        roles: ['patient', 'doctor', 'nurse', 'admin'] 
      },
    ];

    const roleSpecificItems = {
      patient: [
        { id: 'medical-records', title: 'Mon dossier médical', icon: FileText },
        { id: 'prescriptions', title: 'Mes ordonnances', icon: Pill },
        { id: 'doctors', title: 'Mes médecins', icon: Stethoscope },
        { id: 'payments', title: 'Paiements', icon: CreditCard },
      ],
      doctor: [
        { id: 'patients', title: 'Mes patients', icon: Users },
        { id: 'medical-records', title: 'Dossiers médicaux', icon: FileText },
        { id: 'prescriptions', title: 'Ordonnances', icon: Pill },
        { id: 'schedule', title: 'Planning', icon: Calendar },
      ],
      nurse: [
        { id: 'patients', title: 'Patients assignés', icon: Users },
        { id: 'reports', title: 'Rapports de soins', icon: ClipboardList },
        { id: 'schedule', title: 'Planning', icon: Calendar },
        { id: 'medical-records', title: 'Dossiers', icon: FileText },
      ],
      admin: [
        { id: 'users', title: 'Gestion utilisateurs', icon: UserCheck },
        { id: 'doctors', title: 'Médecins', icon: Stethoscope },
        { id: 'patients', title: 'Patients', icon: Users },
        { id: 'reports', title: 'Rapports', icon: ClipboardList },
        { id: 'settings', title: 'Paramètres', icon: Settings },
      ],
    };

    return [
      ...baseItems.filter(item => item.roles.includes(role)),
      ...roleSpecificItems[role],
    ];
  };

  const menuItems = user ? getMenuItems(user.role) : [];

  return (
    <Sidebar className="border-r border-gray-200 bg-bleu-700">
      <SidebarHeader className="border-b border-gray-200 p-4">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-medical-500 rounded-lg flex items-center justify-center">
            <Heart className="w-5 h-5 text-white" />
          </div>
          <div>
            <h2 className="font-semibold text-gray-900">MedSecure</h2>
            <p className="text-xs text-gray-500 capitalize">{user?.role}</p>
          </div>
        </div>
      </SidebarHeader>

      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupLabel>Navigation</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {menuItems.map((item) => (
                <SidebarMenuItem key={item.id}>
                  <SidebarMenuButton 
                    asChild
                    isActive={currentPage === item.id}
                  >
                    <button
                      onClick={() => onPageChange(item.id)}
                      className="w-full flex items-center gap-2 p-2 rounded-lg hover:bg-medical-50 transition-colors"
                    >
                      <item.icon className="w-4 h-4" />
                      <span>{item.title}</span>
                    </button>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>

      <SidebarFooter className="border-t border-gray-200 p-4">
        <div className="space-y-2">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-8 h-8 bg-medical-100 rounded-full flex items-center justify-center">
              <span className="text-sm font-medium text-medical-700">
                {user?.firstName[0]}{user?.lastName[0]}
              </span>
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-gray-900 truncate">
                {user?.firstName} {user?.lastName}
              </p>
              <p className="text-xs text-gray-500 truncate">{user?.email}</p>
            </div>
          </div>
          <Button 
            variant="outline" 
            size="sm" 
            onClick={logout}
            className="w-full"
          >
            <LogOut className="w-4 h-4 mr-2" />
            Déconnexion
          </Button>
        </div>
      </SidebarFooter>
    </Sidebar>
  );
};

export default AppSidebar;
