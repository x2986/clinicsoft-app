
import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Download, Eye, Calendar, User } from 'lucide-react';

interface DocumentViewModalProps {
  isOpen: boolean;
  onClose: () => void;
  document: {
    id: string;
    title: string;
    date: string;
    doctor?: string;
    category?: string;
    content?: string;
  };
}

const DocumentViewModal: React.FC<DocumentViewModalProps> = ({ 
  isOpen, 
  onClose, 
  document 
}) => {
  const handleDownload = () => {
    console.log('Téléchargement du document:', document.id);
    alert('Téléchargement démarré!');
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-2xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Eye className="w-5 h-5 text-medical-600" />
            {document.title}
          </DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4">
          <div className="flex flex-wrap items-center gap-4 text-sm text-gray-600 pb-4 border-b">
            <div className="flex items-center gap-1">
              <Calendar className="w-4 h-4" />
              {new Date(document.date).toLocaleDateString('fr-FR')}
            </div>
            {document.doctor && (
              <div className="flex items-center gap-1">
                <User className="w-4 h-4" />
                {document.doctor}
              </div>
            )}
            {document.category && (
              <span className="text-medical-600 font-medium">
                {document.category}
              </span>
            )}
          </div>
          
          <div className="bg-gray-50 p-6 rounded-lg">
            <h3 className="font-medium text-gray-900 mb-3">Contenu du document</h3>
            <div className="text-gray-700 leading-relaxed">
              {document.content || 'Contenu du document médical... Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.'}
            </div>
          </div>
          
          <div className="flex justify-end gap-2 pt-4 border-t">
            <Button variant="outline" onClick={handleDownload}>
              <Download className="w-4 h-4 mr-2" />
              Télécharger
            </Button>
            <Button onClick={onClose}>
              Fermer
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default DocumentViewModal;
