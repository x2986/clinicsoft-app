
import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { UserPlus } from 'lucide-react';

interface NewPatientModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (patient: any) => void;
}

const NewPatientModal: React.FC<NewPatientModalProps> = ({
  isOpen,
  onClose,
  onSave
}) => {
  const [patientData, setPatientData] = useState({
    firstName: '',
    lastName: '',
    gender: '',
    age: '',
    dateOfBirth: '',
    phone: '',
    address: '',
    emergencyContact: '',
    medicalHistory: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(patientData);
    console.log('Nouveau patient créé:', patientData);
    alert('Nouveau patient créé avec succès!');
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <UserPlus className="w-5 h-5 text-medical-600" />
            Nouveau dossier patient
          </DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="firstName">Prénom</Label>
              <Input
                id="firstName"
                value={patientData.firstName}
                onChange={(e) => setPatientData(prev => ({ ...prev, firstName: e.target.value }))}
                required
              />
            </div>
            
            <div>
              <Label htmlFor="lastName">Nom</Label>
              <Input
                id="lastName"
                value={patientData.lastName}
                onChange={(e) => setPatientData(prev => ({ ...prev, lastName: e.target.value }))}
                required
              />
            </div>
          </div>

          <div className="grid grid-cols-3 gap-4">
            <div>
              <Label htmlFor="gender">Sexe</Label>
              <select
                id="gender"
                value={patientData.gender}
                onChange={(e) => setPatientData(prev => ({ ...prev, gender: e.target.value }))}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-medical-500"
                required
              >
                <option value="">Sélectionner</option>
                <option value="M">Masculin</option>
                <option value="F">Féminin</option>
              </select>
            </div>
            
            <div>
              <Label htmlFor="age">Âge</Label>
              <Input
                id="age"
                type="number"
                value={patientData.age}
                onChange={(e) => setPatientData(prev => ({ ...prev, age: e.target.value }))}
                required
              />
            </div>
            
            <div>
              <Label htmlFor="dateOfBirth">Date de naissance</Label>
              <Input
                id="dateOfBirth"
                type="date"
                value={patientData.dateOfBirth}
                onChange={(e) => setPatientData(prev => ({ ...prev, dateOfBirth: e.target.value }))}
                required
              />
            </div>
          </div>

          <div>
            <Label htmlFor="phone">Téléphone</Label>
            <Input
              id="phone"
              value={patientData.phone}
              onChange={(e) => setPatientData(prev => ({ ...prev, phone: e.target.value }))}
              placeholder="+237 6 XX XX XX XX"
              required
            />
          </div>

          <div>
            <Label htmlFor="address">Adresse</Label>
            <Input
              id="address"
              value={patientData.address}
              onChange={(e) => setPatientData(prev => ({ ...prev, address: e.target.value }))}
              placeholder="Adresse complète"
              required
            />
          </div>

          <div>
            <Label htmlFor="emergencyContact">Contact d'urgence</Label>
            <Input
              id="emergencyContact"
              value={patientData.emergencyContact}
              onChange={(e) => setPatientData(prev => ({ ...prev, emergencyContact: e.target.value }))}
              placeholder="Nom et téléphone du contact d'urgence"
            />
          </div>

          <div>
            <Label htmlFor="medicalHistory">Antécédents médicaux</Label>
            <textarea
              id="medicalHistory"
              value={patientData.medicalHistory}
              onChange={(e) => setPatientData(prev => ({ ...prev, medicalHistory: e.target.value }))}
              placeholder="Allergies, maladies chroniques, chirurgies précédentes..."
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-medical-500"
              rows={3}
            />
          </div>

          <div className="flex justify-end gap-2 pt-4">
            <Button type="button" variant="outline" onClick={onClose}>
              Annuler
            </Button>
            <Button type="submit" className="bg-medical-500 hover:bg-medical-600">
              <UserPlus className="w-4 h-4 mr-2" />
              Créer le dossier
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default NewPatientModal;
