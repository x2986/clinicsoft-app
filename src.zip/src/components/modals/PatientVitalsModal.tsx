
import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Activity, Heart, Thermometer, Weight, TrendingUp } from 'lucide-react';

interface PatientVitalsModalProps {
  isOpen: boolean;
  onClose: () => void;
  patientName: string;
  onSave: (vitals: any) => void;
}

const PatientVitalsModal: React.FC<PatientVitalsModalProps> = ({
  isOpen,
  onClose,
  patientName,
  onSave
}) => {
  const [vitals, setVitals] = useState({
    bloodPressure: '',
    temperature: '',
    weight: '',
    heartRate: '',
    bloodSugar: '',
    notes: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(vitals);
    console.log('Paramètres vitaux sauvegardés:', vitals);
    alert('Paramètres vitaux enregistrés avec succès!');
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Activity className="w-5 h-5 text-medical-600" />
            Paramètres vitaux - {patientName}
          </DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="bloodPressure">Tension artérielle</Label>
              <Input
                id="bloodPressure"
                value={vitals.bloodPressure}
                onChange={(e) => setVitals(prev => ({ ...prev, bloodPressure: e.target.value }))}
                placeholder="120/80 mmHg"
                required
              />
            </div>
            
            <div>
              <Label htmlFor="temperature">Température</Label>
              <Input
                id="temperature"
                value={vitals.temperature}
                onChange={(e) => setVitals(prev => ({ ...prev, temperature: e.target.value }))}
                placeholder="36.5°C"
                required
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="weight">Poids</Label>
              <Input
                id="weight"
                value={vitals.weight}
                onChange={(e) => setVitals(prev => ({ ...prev, weight: e.target.value }))}
                placeholder="70 kg"
                required
              />
            </div>
            
            <div>
              <Label htmlFor="heartRate">Fréquence cardiaque</Label>
              <Input
                id="heartRate"
                value={vitals.heartRate}
                onChange={(e) => setVitals(prev => ({ ...prev, heartRate: e.target.value }))}
                placeholder="72 bpm"
                required
              />
            </div>
          </div>

          <div>
            <Label htmlFor="bloodSugar">Glycémie</Label>
            <Input
              id="bloodSugar"
              value={vitals.bloodSugar}
              onChange={(e) => setVitals(prev => ({ ...prev, bloodSugar: e.target.value }))}
              placeholder="5.6 mmol/L"
            />
          </div>

          <div>
            <Label htmlFor="notes">Notes supplémentaires</Label>
            <textarea
              id="notes"
              value={vitals.notes}
              onChange={(e) => setVitals(prev => ({ ...prev, notes: e.target.value }))}
              placeholder="Observations particulières..."
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-medical-500"
              rows={3}
            />
          </div>

          <div className="flex justify-end gap-2 pt-4">
            <Button type="button" variant="outline" onClick={onClose}>
              Annuler
            </Button>
            <Button type="submit" className="bg-medical-500 hover:bg-medical-600">
              <Activity className="w-4 h-4 mr-2" />
              Enregistrer
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default PatientVitalsModal;
