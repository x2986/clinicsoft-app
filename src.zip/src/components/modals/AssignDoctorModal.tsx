
import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { UserCheck, Stethoscope } from 'lucide-react';

interface AssignDoctorModalProps {
  isOpen: boolean;
  onClose: () => void;
  patientName: string;
  onAssign: (doctorId: string) => void;
}

const AssignDoctorModal: React.FC<AssignDoctorModalProps> = ({
  isOpen,
  onClose,
  patientName,
  onAssign
}) => {
  const [selectedDoctor, setSelectedDoctor] = useState('');

  const availableDoctors = [
    { id: '1', name: 'Dr. Paul Mbarga', specialty: 'Cardiologie', status: 'Disponible' },
    { id: '2', name: 'Dr. Marie Nkomo', specialty: 'Pédiatrie', status: 'Disponible' },
    { id: '3', name: 'Dr. Jean Fouda', specialty: 'Dermatologie', status: 'Occupé' },
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (selectedDoctor) {
      onAssign(selectedDoctor);
      console.log('Patient assigné au médecin:', selectedDoctor);
      alert(`Patient ${patientName} assigné au médecin avec succès!`);
      onClose();
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <UserCheck className="w-5 h-5 text-medical-600" />
            Assigner un médecin - {patientName}
          </DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label>Sélectionner un médecin disponible</Label>
            <div className="space-y-2 mt-2">
              {availableDoctors.map((doctor) => (
                <div 
                  key={doctor.id}
                  className={`p-3 border rounded-lg cursor-pointer transition-colors ${
                    selectedDoctor === doctor.id 
                      ? 'border-medical-500 bg-medical-50' 
                      : 'border-gray-200 hover:border-gray-300'
                  } ${doctor.status === 'Occupé' ? 'opacity-50' : ''}`}
                  onClick={() => doctor.status === 'Disponible' && setSelectedDoctor(doctor.id)}
                >
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 bg-medical-100 rounded-full flex items-center justify-center">
                      <Stethoscope className="w-4 h-4 text-medical-600" />
                    </div>
                    <div className="flex-1">
                      <div className="font-medium text-gray-900">{doctor.name}</div>
                      <div className="text-sm text-gray-600">{doctor.specialty}</div>
                    </div>
                    <div className={`text-sm font-medium ${
                      doctor.status === 'Disponible' ? 'text-green-600' : 'text-orange-600'
                    }`}>
                      {doctor.status}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-4">
            <Button type="button" variant="outline" onClick={onClose}>
              Annuler
            </Button>
            <Button 
              type="submit" 
              className="bg-medical-500 hover:bg-medical-600"
              disabled={!selectedDoctor}
            >
              <UserCheck className="w-4 h-4 mr-2" />
              Assigner
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default AssignDoctorModal;
