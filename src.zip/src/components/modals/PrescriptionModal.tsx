
import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Pill, Plus, Trash2 } from 'lucide-react';

interface PrescriptionModalProps {
  isOpen: boolean;
  onClose: () => void;
  patientName: string;
  onSave: (prescription: any) => void;
}

const PrescriptionModal: React.FC<PrescriptionModalProps> = ({
  isOpen,
  onClose,
  patientName,
  onSave
}) => {
  const [prescription, setPrescription] = useState({
    diagnosis: '',
    medications: [{ name: '', dosage: '', duration: '', instructions: '' }],
    medicalPrescription: '',
    notes: ''
  });

  const addMedication = () => {
    setPrescription(prev => ({
      ...prev,
      medications: [...prev.medications, { name: '', dosage: '', duration: '', instructions: '' }]
    }));
  };

  const removeMedication = (index: number) => {
    setPrescription(prev => ({
      ...prev,
      medications: prev.medications.filter((_, i) => i !== index)
    }));
  };

  const updateMedication = (index: number, field: string, value: string) => {
    setPrescription(prev => ({
      ...prev,
      medications: prev.medications.map((med, i) => 
        i === index ? { ...med, [field]: value } : med
      )
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(prescription);
    console.log('Ordonnance créée:', prescription);
    alert('Ordonnance créée avec succès!');
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Pill className="w-5 h-5 text-medical-600" />
            Nouvelle ordonnance - {patientName}
          </DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <Label htmlFor="diagnosis">Diagnostic</Label>
            <Input
              id="diagnosis"
              value={prescription.diagnosis}
              onChange={(e) => setPrescription(prev => ({ ...prev, diagnosis: e.target.value }))}
              placeholder="Diagnostic principal"
              required
            />
          </div>

          <div>
            <div className="flex items-center justify-between mb-4">
              <Label>Médicaments</Label>
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={addMedication}
              >
                <Plus className="w-4 h-4 mr-2" />
                Ajouter un médicament
              </Button>
            </div>

            <div className="space-y-4">
              {prescription.medications.map((medication, index) => (
                <div key={index} className="p-4 border rounded-lg bg-gray-50">
                  <div className="flex justify-between items-center mb-3">
                    <h4 className="font-medium">Médicament {index + 1}</h4>
                    {prescription.medications.length > 1 && (
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        onClick={() => removeMedication(index)}
                        className="text-red-600 hover:text-red-700"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    )}
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label>Nom du médicament</Label>
                      <Input
                        value={medication.name}
                        onChange={(e) => updateMedication(index, 'name', e.target.value)}
                        placeholder="Ex: Paracétamol 500mg"
                        required
                      />
                    </div>
                    
                    <div>
                      <Label>Posologie</Label>
                      <Input
                        value={medication.dosage}
                        onChange={(e) => updateMedication(index, 'dosage', e.target.value)}
                        placeholder="Ex: 1 comprimé 3 fois par jour"
                        required
                      />
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4 mt-4">
                    <div>
                      <Label>Durée</Label>
                      <Input
                        value={medication.duration}
                        onChange={(e) => updateMedication(index, 'duration', e.target.value)}
                        placeholder="Ex: 7 jours"
                        required
                      />
                    </div>
                    
                    <div>
                      <Label>Instructions</Label>
                      <Input
                        value={medication.instructions}
                        onChange={(e) => updateMedication(index, 'instructions', e.target.value)}
                        placeholder="Ex: Après les repas"
                      />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div>
            <Label htmlFor="medicalPrescription">Prescription médicale</Label>
            <Textarea
              id="medicalPrescription"
              value={prescription.medicalPrescription}
              onChange={(e) => setPrescription(prev => ({ ...prev, medicalPrescription: e.target.value }))}
              placeholder="Repos, examens complémentaires, conseils..."
              rows={4}
            />
          </div>

          <div>
            <Label htmlFor="notes">Notes supplémentaires</Label>
            <Textarea
              id="notes"
              value={prescription.notes}
              onChange={(e) => setPrescription(prev => ({ ...prev, notes: e.target.value }))}
              placeholder="Observations particulières..."
              rows={3}
            />
          </div>

          <div className="flex justify-end gap-2 pt-4">
            <Button type="button" variant="outline" onClick={onClose}>
              Annuler
            </Button>
            <Button type="submit" className="bg-medical-500 hover:bg-medical-600">
              <Pill className="w-4 h-4 mr-2" />
              Créer l'ordonnance
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default PrescriptionModal;
