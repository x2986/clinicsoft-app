
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Calendar, Clock, User, Plus, Edit, Trash2 } from 'lucide-react';
import { UserRole } from '@/contexts/AuthContext';
import NewAppointmentModal from '@/components/modals/NewAppointmentModal';

interface AppointmentCalendarProps {
  userRole: UserRole;
}

const AppointmentCalendar: React.FC<AppointmentCalendarProps> = ({ userRole }) => {
  const [isNewAppointmentOpen, setIsNewAppointmentOpen] = useState(false);
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);

  const appointments = [
    {
      id: '1',
      patient: 'Marie Dupont',
      doctor: 'Dr. Martin',
      date: '2024-06-27',
      time: '09:00',
      duration: 30,
      type: 'Consultation',
      status: 'confirmed'
    },
    {
      id: '2',
      patient: 'Jean Dubois',
      doctor: 'Dr. Lefebvre',
      date: '2024-06-27',
      time: '10:30',
      duration: 45,
      type: 'Contrôle',
      status: 'pending'
    }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'confirmed': return 'bg-green-100 text-green-800';
      case 'pending': return 'bg-yellow-100 text-yellow-800';
      case 'cancelled': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Rendez-vous</h2>
          <p className="text-gray-600">
            {userRole === 'patient' ? 'Gérez vos rendez-vous médicaux' : 'Planning des consultations'}
          </p>
        </div>
        <Button 
          onClick={() => setIsNewAppointmentOpen(true)}
          className="bg-medical-500 hover:bg-medical-600"
        >
          <Plus className="w-4 h-4 mr-2" />
          Nouveau RDV
        </Button>
      </div>

      <div className="flex items-center gap-4">
        <input
          type="date"
          value={selectedDate}
          onChange={(e) => setSelectedDate(e.target.value)}
          className="px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-medical-500"
        />
      </div>

      <div className="grid gap-4">
        {appointments.map((appointment) => (
          <Card key={appointment.id} className="medical-card">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-medical-100 rounded-lg flex items-center justify-center">
                    <Calendar className="w-6 h-6 text-medical-600" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900">{appointment.type}</h3>
                    <div className="flex items-center gap-4 text-sm text-gray-600 mt-1">
                      {userRole !== 'patient' && (
                        <div className="flex items-center gap-1">
                          <User className="w-4 h-4" />
                          <span>{appointment.patient}</span>
                        </div>
                      )}
                      {userRole === 'patient' && (
                        <div className="flex items-center gap-1">
                          <User className="w-4 h-4" />
                          <span>{appointment.doctor}</span>
                        </div>
                      )}
                      <div className="flex items-center gap-1">
                        <Clock className="w-4 h-4" />
                        <span>{appointment.time} ({appointment.duration}min)</span>
                      </div>
                    </div>
                  </div>
                </div>
                
                <div className="flex items-center gap-3">
                  <Badge className={getStatusColor(appointment.status)}>
                    {appointment.status === 'confirmed' ? 'Confirmé' : 
                     appointment.status === 'pending' ? 'En attente' : 'Annulé'}
                  </Badge>
                  
                  <div className="flex gap-2">
                    <Button size="sm" variant="outline">
                      <Edit className="w-4 h-4" />
                    </Button>
                    <Button size="sm" variant="outline" className="text-red-600 hover:text-red-700">
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <NewAppointmentModal
        isOpen={isNewAppointmentOpen}
        onClose={() => setIsNewAppointmentOpen(false)}
        userRole={userRole}
      />
    </div>
  );
};

export default AppointmentCalendar;
