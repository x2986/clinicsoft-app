
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  FileText, 
  Download, 
  Eye, 
  Plus,
  Calendar,
  User,
  Clock,
  CheckCircle,
  AlertCircle,
  Printer
} from 'lucide-react';
import { UserRole } from '@/contexts/AuthContext';

interface ReportsSectionProps {
  userRole: UserRole;
}

const ReportsSection: React.FC<ReportsSectionProps> = ({ userRole }) => {
  const [selectedPeriod, setSelectedPeriod] = useState('month');

  const reports = [
    {
      id: '1',
      title: 'Rapport de soins infirmiers',
      patient: 'Marie Dupont',
      type: 'Soins',
      date: '2024-01-15',
      time: '14:30',
      status: 'completed',
      priority: 'normal',
      description: 'Suivi post-opératoire, pansement changé, constantes vitales normales'
    },
    {
      id: '2',
      title: 'Rapport d\'examen médical',
      patient: 'Jean Martin',
      type: 'Consultation',
      date: '2024-01-14',
      time: '09:15',
      status: 'pending',
      priority: 'high',
      description: 'Examen cardiologique de routine, résultats en attente'
    },
    {
      id: '3',
      title: 'Rapport d\'urgence',
      patient: 'Sophie Leroy',
      type: 'Urgence',
      date: '2024-01-13',
      time: '22:45',
      status: 'completed',
      priority: 'urgent',
      description: 'Prise en charge urgente, patient stabilisé'
    },
    {
      id: '4',
      title: 'Rapport de téléconsultation',
      patient: 'Paul Dubois',
      type: 'Téléconsultation',
      date: '2024-01-12',
      time: '16:00',
      status: 'completed',
      priority: 'normal',
      description: 'Suivi médical à distance, ajustement traitement'
    }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return 'bg-green-100 text-green-800';
      case 'pending': return 'bg-yellow-100 text-yellow-800';
      case 'review': return 'bg-blue-100 text-blue-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case 'completed': return 'Terminé';
      case 'pending': return 'En attente';
      case 'review': return 'À réviser';
      default: return status;
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'urgent': return 'text-red-600';
      case 'high': return 'text-orange-600';
      case 'normal': return 'text-green-600';
      default: return 'text-gray-600';
    }
  };

  const getPriorityIcon = (priority: string) => {
    switch (priority) {
      case 'urgent': return AlertCircle;
      case 'high': return AlertCircle;
      default: return CheckCircle;
    }
  };

  const stats = [
    { label: 'Rapports ce mois', value: '24', change: '+12%', color: 'text-blue-600' },
    { label: 'En attente', value: '3', change: '-25%', color: 'text-yellow-600' },
    { label: 'Terminés', value: '21', change: '+18%', color: 'text-green-600' },
    { label: 'Urgences', value: '2', change: '0%', color: 'text-red-600' }
  ];

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Rapports médicaux</h2>
          <p className="text-gray-600">
            {userRole === 'nurse' 
              ? 'Gérez vos rapports de soins et examens'
              : 'Consultez les rapports médicaux'
            }
          </p>
        </div>
        
        {(userRole === 'nurse' || userRole === 'doctor') && (
          <div className="flex gap-2">
            <Button variant="outline">
              <Printer className="w-4 h-4 mr-2" />
              Imprimer
            </Button>
            <Button className="medical-button">
              <Plus className="w-4 h-4 mr-2" />
              Nouveau rapport
            </Button>
          </div>
        )}
      </div>

      {/* Statistiques */}
      {userRole !== 'patient' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {stats.map((stat, index) => (
            <Card key={index} className="medical-card">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">{stat.label}</p>
                    <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
                  </div>
                  <div className={`text-sm font-medium ${stat.color}`}>
                    {stat.change}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Filtres de période */}
      <div className="flex gap-2">
        {['week', 'month', 'quarter', 'year'].map((period) => (
          <Button
            key={period}
            variant={selectedPeriod === period ? "default" : "outline"}
            size="sm"
            onClick={() => setSelectedPeriod(period)}
          >
            {period === 'week' && 'Cette semaine'}
            {period === 'month' && 'Ce mois'}
            {period === 'quarter' && 'Ce trimestre'}
            {period === 'year' && 'Cette année'}
          </Button>
        ))}
      </div>

      {/* Liste des rapports */}
      <div className="grid grid-cols-1 gap-4">
        {reports.map((report) => {
          const PriorityIcon = getPriorityIcon(report.priority);
          
          return (
            <Card key={report.id} className="medical-card hover:shadow-md transition-shadow">
              <CardContent className="p-6">
                <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
                  <div className="flex-1">
                    <div className="flex items-start gap-3">
                      <div className="w-10 h-10 bg-medical-100 rounded-lg flex items-center justify-center flex-shrink-0">
                        <FileText className="w-5 h-5 text-medical-600" />
                      </div>
                      
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <h3 className="text-lg font-medium text-gray-900">
                            {report.title}
                          </h3>
                          <PriorityIcon className={`w-4 h-4 ${getPriorityColor(report.priority)}`} />
                        </div>
                        
                        <div className="flex flex-wrap items-center gap-4 text-sm text-gray-600 mb-2">
                          <div className="flex items-center gap-1">
                            <User className="w-4 h-4" />
                            {report.patient}
                          </div>
                          <div className="flex items-center gap-1">
                            <Calendar className="w-4 h-4" />
                            {new Date(report.date).toLocaleDateString('fr-FR')}
                          </div>
                          <div className="flex items-center gap-1">
                            <Clock className="w-4 h-4" />
                            {report.time}
                          </div>
                          <span className="text-medical-600 font-medium">
                            {report.type}
                          </span>
                        </div>
                        
                        <p className="text-gray-600 text-sm mb-3">
                          {report.description}
                        </p>
                        
                        <Badge className={getStatusColor(report.status)}>
                          {getStatusLabel(report.status)}
                        </Badge>
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-2">
                    <Button variant="outline" size="sm">
                      <Eye className="w-4 h-4 mr-2" />
                      Voir
                    </Button>
                    <Button variant="outline" size="sm">
                      <Download className="w-4 h-4 mr-2" />
                      Télécharger
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {reports.length === 0 && (
        <Card className="medical-card">
          <CardContent className="p-12 text-center">
            <FileText className="w-12 h-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">
              Aucun rapport trouvé
            </h3>
            <p className="text-gray-600">
              Aucun rapport médical disponible pour la période sélectionnée
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default ReportsSection;
