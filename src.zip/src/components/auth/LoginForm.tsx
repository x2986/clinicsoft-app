
import React, { useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Heart, Mail, Lock, Loader2, Shield, Calendar, Users, Stethoscope } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

const LoginForm = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const { login, isLoading } = useAuth();
  const { toast } = useToast();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await login(email, password);
      toast({
        title: "Connexion réussie",
        description: "Bienvenue dans votre espace médical",
      });
    } catch (error) {
      toast({
        title: "Erreur de connexion",
        description: "Vérifiez vos identifiants",
        variant: "destructive",
      });
    }
  };

  const demoAccounts = [
    { email: 'doctor@medical.cm', role: 'Médecin', password: 'demo123' },
    { email: 'patient@medical.cm', role: 'Patient', password: 'demo123' },
    { email: 'nurse@medical.cm', role: 'Infirmier', password: 'demo123' },
    { email: 'admin@medical.cm', role: 'Administrateur', password: 'demo123' },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-medical-50 to-medical-100 flex">
      {/* Left Side - Login Form */}
      <div className="w-full lg:w-1/2 flex items-center justify-center p-8">
        <div className="w-full max-w-md">
          <div className="text-center mb-8">
            <div className="mx-auto w-16 h-16 bg-medical-500 rounded-full flex items-center justify-center mb-4">
              <Heart className="w-8 h-8 text-white" />
            </div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">MedSecure</h1>
            <p className="text-gray-600">Plateforme de gestion médicale sécurisée</p>
          </div>

          <Card className="medical-card">
            <CardHeader>
              <CardTitle className="text-center">Connexion</CardTitle>
              <CardDescription className="text-center">
                Accédez à votre espace médical personnel
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="email">Email</Label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                    <Input
                      id="email"
                      type="email"
                      placeholder="votre@email.cm"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="pl-10"
                      required
                    />
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="password">Mot de passe</Label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                    <Input
                      id="password"
                      type="password"
                      placeholder="••••••••"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="pl-10"
                      required
                    />
                  </div>
                </div>

                <Button 
                  type="submit" 
                  className="w-full medical-button"
                  disabled={isLoading}
                >
                  {isLoading ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Connexion...
                    </>
                  ) : (
                    'Se connecter'
                  )}
                </Button>
              </form>

              <div className="mt-6">
                <div className="relative">
                  <div className="absolute inset-0 flex items-center">
                    <span className="w-full border-t border-gray-300" />
                  </div>
                  <div className="relative flex justify-center text-xs uppercase">
                    <span className="bg-white px-2 text-gray-500">Comptes de démonstration</span>
                  </div>
                </div>

                <div className="mt-4 space-y-2">
                  {demoAccounts.map((account, index) => (
                    <Button
                      key={index}
                      type="button"
                      variant="outline"
                      className="w-full justify-start"
                      onClick={() => {
                        setEmail(account.email);
                        setPassword(account.password);
                      }}
                    >
                      <span className="font-medium">{account.role}</span>
                      <span className="ml-auto text-sm text-gray-500">{account.email}</span>
                    </Button>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Right Side - Content */}
      <div className="hidden lg:flex lg:w-1/2 bg-medical-500 items-center justify-center p-8 text-white">
        <div className="max-w-md text-center">
          <h2 className="text-4xl font-bold mb-6">
            Bienvenue sur MedSecure
          </h2>
          <p className="text-xl mb-8 text-medical-100">
            La solution complète pour la gestion de votre santé au Cameroun
          </p>
          
          <div className="space-y-6">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-medical-400 rounded-lg flex items-center justify-center">
                <Shield className="w-6 h-6" />
              </div>
              <div className="text-left">
                <h3 className="font-semibold">Sécurité maximale</h3>
                <p className="text-sm text-medical-100">Vos données médicales sont protégées</p>
              </div>
            </div>
            
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-medical-400 rounded-lg flex items-center justify-center">
                <Calendar className="w-6 h-6" />
              </div>
              <div className="text-left">
                <h3 className="font-semibold">Gestion simplifiée</h3>
                <p className="text-sm text-medical-100">Rendez-vous et suivi médical en un clic</p>
              </div>
            </div>
            
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-medical-400 rounded-lg flex items-center justify-center">
                <Users className="w-6 h-6" />
              </div>
              <div className="text-left">
                <h3 className="font-semibold">Équipe qualifiée</h3>
                <p className="text-sm text-medical-100">Médecins et infirmiers à votre service</p>
              </div>
            </div>
            
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-medical-400 rounded-lg flex items-center justify-center">
                <Stethoscope className="w-6 h-6" />
              </div>
              <div className="text-left">
                <h3 className="font-semibold">Soins de qualité</h3>
                <p className="text-sm text-medical-100">Standards internationaux au Cameroun</p>
              </div>
            </div>
          </div>
          
          <div className="mt-8 p-4 bg-medical-400 rounded-lg">
            <p className="text-sm">
              "Une plateforme moderne pour une santé moderne au cœur de l'Afrique"
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LoginForm;
