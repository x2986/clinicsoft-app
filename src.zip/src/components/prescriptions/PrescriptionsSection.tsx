
import React, { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { 
  Pill, 
  Plus,
  Search,
  Printer
} from 'lucide-react';
import { UserRole } from '@/contexts/AuthContext';
import DocumentViewModal from '@/components/modals/DocumentViewModal';
import PrescriptionCard from './PrescriptionCard';

interface PrescriptionsSectionProps {
  userRole: UserRole;
}

const PrescriptionsSection: React.FC<PrescriptionsSectionProps> = ({ userRole }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedStatus, setSelectedStatus] = useState('all');
  const [viewingPrescription, setViewingPrescription] = useState<any>(null);

  const prescriptions = [
    {
      id: '1',
      title: 'Ordonnance - Amoxicilline + Paracétamol',
      patientName: 'Marie Nkomo',
      doctorName: 'Dr. Mbarga',
      medications: [
        { name: 'Amoxicilline 500mg', dosage: '1 comprimé 3x/jour', duration: '7 jours' },
        { name: 'Paracétamol 1000mg', dosage: '1 comprimé si douleur', duration: 'selon besoin' }
      ],
      date: '2024-01-15',
      expiryDate: '2024-04-15',
      status: 'active',
      diagnosis: 'Infection respiratoire',
      instructions: 'À prendre pendant les repas',
      content: 'Prescription complète pour traitement de l\'infection respiratoire. Amoxicilline 500mg, 1 comprimé 3 fois par jour pendant 7 jours. Paracétamol 1000mg selon les besoins pour la douleur.'
    }
  ];

  const handleView = (prescription: any) => {
    const docFormat = {
      id: prescription.id,
      title: prescription.title,
      date: prescription.date,
      doctor: prescription.doctorName,
      category: 'Ordonnance',
      content: prescription.content
    };
    setViewingPrescription(docFormat);
  };

  const handleDownload = (prescription: any) => {
    console.log('Téléchargement ordonnance:', prescription.id);
    alert(`Téléchargement de l'ordonnance "${prescription.title}" démarré!`);
  };

  const filteredPrescriptions = prescriptions.filter(prescription => {
    const matchesSearch = prescription.patientName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         prescription.doctorName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         prescription.diagnosis.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         prescription.medications.some(med => 
                           med.name.toLowerCase().includes(searchTerm.toLowerCase())
                         );
    const matchesStatus = selectedStatus === 'all' || prescription.status === selectedStatus;
    return matchesSearch && matchesStatus;
  });

  const stats = [
    { label: 'Ordonnances actives', value: '18', color: 'text-green-600' },
    { label: 'Expirées ce mois', value: '3', color: 'text-red-600' },
    { label: 'En attente', value: '2', color: 'text-yellow-600' },
    { label: 'Total prescrit', value: '156', color: 'text-blue-600' }
  ];

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">
            {userRole === 'patient' ? 'Mes ordonnances' : 'Ordonnances'}
          </h2>
          <p className="text-gray-600">
            {userRole === 'patient' 
              ? 'Consultez vos prescriptions médicales'
              : 'Gérez les prescriptions de vos patients'
            }
          </p>
        </div>
        
        {userRole === 'doctor' && (
          <div className="flex gap-2">
            <Button variant="outline">
              <Printer className="w-4 h-4 mr-2" />
              Imprimer
            </Button>
            <Button className="medical-button">
              <Plus className="w-4 h-4 mr-2" />
              Nouvelle ordonnance
            </Button>
          </div>
        )}
      </div>

      {userRole === 'doctor' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {stats.map((stat, index) => (
            <Card key={index} className="medical-card">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">{stat.label}</p>
                    <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
                  </div>
                  <Pill className={`w-8 h-8 ${stat.color}`} />
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      <div className="flex flex-col lg:flex-row gap-4">
        <div className="flex-1">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
            <Input
              placeholder="Rechercher une ordonnance..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
        </div>
        
        <div className="flex gap-2">
          {['all', 'active', 'expired', 'pending'].map((status) => (
            <Button
              key={status}
              variant={selectedStatus === status ? "default" : "outline"}
              size="sm"
              onClick={() => setSelectedStatus(status)}
            >
              {status === 'all' && 'Toutes'}
              {status === 'active' && 'Actives'}
              {status === 'expired' && 'Expirées'}
              {status === 'pending' && 'En attente'}
            </Button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 gap-6">
        {filteredPrescriptions.map((prescription) => (
          <PrescriptionCard
            key={prescription.id}
            prescription={prescription}
            userRole={userRole}
            onView={handleView}
            onDownload={handleDownload}
          />
        ))}
      </div>

      {filteredPrescriptions.length === 0 && (
        <Card className="medical-card">
          <CardContent className="p-12 text-center">
            <Pill className="w-12 h-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">
              Aucune ordonnance trouvée
            </h3>
            <p className="text-gray-600">
              {searchTerm 
                ? 'Essayez de modifier votre recherche'
                : 'Aucune ordonnance disponible pour le moment'
              }
            </p>
          </CardContent>
        </Card>
      )}

      {viewingPrescription && (
        <DocumentViewModal
          isOpen={!!viewingPrescription}
          onClose={() => setViewingPrescription(null)}
          document={viewingPrescription}
        />
      )}
    </div>
  );
};

export default PrescriptionsSection;
