
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  Pill, 
  Download, 
  Eye, 
  Calendar,
  User,
  CheckCircle,
  AlertCircle,
  Clock
} from 'lucide-react';

interface Prescription {
  id: string;
  title: string;
  patientName: string;
  doctorName: string;
  medications: Array<{
    name: string;
    dosage: string;
    duration: string;
  }>;
  date: string;
  expiryDate: string;
  status: string;
  diagnosis: string;
  instructions: string;
  content: string;
}

interface PrescriptionCardProps {
  prescription: Prescription;
  userRole: string;
  onView: (prescription: Prescription) => void;
  onDownload: (prescription: Prescription) => void;
}

const PrescriptionCard: React.FC<PrescriptionCardProps> = ({
  prescription,
  userRole,
  onView,
  onDownload
}) => {
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'bg-green-100 text-green-800';
      case 'expired': return 'bg-red-100 text-red-800';
      case 'pending': return 'bg-yellow-100 text-yellow-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case 'active': return 'Active';
      case 'expired': return 'Expirée';
      case 'pending': return 'En attente';
      default: return status;
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'active': return CheckCircle;
      case 'expired': return AlertCircle;
      default: return Clock;
    }
  };

  const StatusIcon = getStatusIcon(prescription.status);

  return (
    <Card className="medical-card hover:shadow-md transition-shadow">
      <CardHeader className="pb-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-medical-100 rounded-lg flex items-center justify-center">
              <Pill className="w-6 h-6 text-medical-600" />
            </div>
            <div>
              <CardTitle className="text-lg">
                Ordonnance du {new Date(prescription.date).toLocaleDateString('fr-FR')}
              </CardTitle>
              <div className="flex items-center gap-4 text-sm text-gray-600">
                {userRole !== 'patient' && (
                  <div className="flex items-center gap-1">
                    <User className="w-4 h-4" />
                    {prescription.patientName}
                  </div>
                )}
                <div className="flex items-center gap-1">
                  <User className="w-4 h-4" />
                  {prescription.doctorName}
                </div>
              </div>
            </div>
          </div>
          
          <div className="flex items-center gap-3">
            <Badge className={getStatusColor(prescription.status)}>
              <StatusIcon className="w-3 h-3 mr-1" />
              {getStatusLabel(prescription.status)}
            </Badge>
          </div>
        </div>
      </CardHeader>
      
      <CardContent className="space-y-4">
        <div>
          <h4 className="font-medium text-gray-900 mb-2">Diagnostic</h4>
          <p className="text-gray-600">{prescription.diagnosis}</p>
        </div>
        
        <div>
          <h4 className="font-medium text-gray-900 mb-3">Médicaments prescrits</h4>
          <div className="space-y-3">
            {prescription.medications.map((medication, index) => (
              <div key={index} className="bg-gray-50 p-4 rounded-lg">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <div>
                    <h5 className="font-medium text-gray-900">{medication.name}</h5>
                    <p className="text-sm text-gray-600">{medication.dosage}</p>
                  </div>
                  <div className="text-sm text-medical-600 font-medium">
                    Durée: {medication.duration}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
        
        <div>
          <h4 className="font-medium text-gray-900 mb-2">Instructions</h4>
          <p className="text-gray-600">{prescription.instructions}</p>
        </div>
        
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pt-4 border-t">
          <div className="text-sm text-gray-600">
            <span>Expire le: </span>
            <span className="font-medium">
              {new Date(prescription.expiryDate).toLocaleDateString('fr-FR')}
            </span>
          </div>
          
          <div className="flex items-center gap-2">
            <Button 
              variant="outline" 
              size="sm"
              onClick={() => onView(prescription)}
            >
              <Eye className="w-4 h-4 mr-2" />
              Voir détails
            </Button>
            <Button 
              variant="outline" 
              size="sm"
              onClick={() => onDownload(prescription)}
            >
              <Download className="w-4 h-4 mr-2" />
              Télécharger
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default PrescriptionCard;
