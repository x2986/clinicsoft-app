
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { 
  Search, 
  Plus, 
  Phone, 
  Mail, 
  Calendar, 
  FileText, 
  Activity,
  UserCheck,
  Stethoscope 
} from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import NewPatientModal from '@/components/modals/NewPatientModal';
import PatientVitalsModal from '@/components/modals/PatientVitalsModal';
import AssignDoctorModal from '@/components/modals/AssignDoctorModal';
import PrescriptionModal from '@/components/modals/PrescriptionModal';

interface Patient {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  dateOfBirth: string;
  lastVisit: string;
  condition: string;
  status: 'active' | 'inactive' | 'urgent';
  assignedDoctor?: string;
  vitals?: any;
}

const PatientsList: React.FC = () => {
  const { user } = useAuth();
  const [searchTerm, setSearchTerm] = useState('');
  const [isNewPatientOpen, setIsNewPatientOpen] = useState(false);
  const [isVitalsOpen, setIsVitalsOpen] = useState(false);
  const [isAssignDoctorOpen, setIsAssignDoctorOpen] = useState(false);
  const [isPrescriptionOpen, setIsPrescriptionOpen] = useState(false);
  const [selectedPatient, setSelectedPatient] = useState<Patient | null>(null);
  
  const patients: Patient[] = [
    {
      id: '1',
      firstName: 'Pierre',
      lastName: 'Nkomo',
      email: 'pierre.nkomo@email.com',
      phone: '+237 6 70 12 34 56',
      dateOfBirth: '1980-05-15',
      lastVisit: '2024-01-15',
      condition: 'Hypertension',
      status: 'active',
      assignedDoctor: 'Dr. Mbarga'
    },
    {
      id: '2',
      firstName: 'Marie',
      lastName: 'Fouda',
      email: 'marie.fouda@email.com',
      phone: '+237 6 70 12 34 57',
      dateOfBirth: '1975-09-22',
      lastVisit: '2024-01-10',
      condition: 'Diabète Type 2',
      status: 'urgent'
    }
  ];

  const filteredPatients = patients.filter(patient =>
    `${patient.firstName} ${patient.lastName}`.toLowerCase().includes(searchTerm.toLowerCase()) ||
    patient.email.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'bg-green-100 text-green-800';
      case 'urgent': return 'bg-red-100 text-red-800';
      case 'inactive': return 'bg-gray-100 text-gray-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getAge = (dateOfBirth: string) => {
    const today = new Date();
    const birthDate = new Date(dateOfBirth);
    let age = today.getFullYear() - birthDate.getFullYear();
    const monthDiff = today.getMonth() - birthDate.getMonth();
    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
      age--;
    }
    return age;
  };

  const handlePatientAction = (patient: Patient, action: string) => {
    setSelectedPatient(patient);
    switch (action) {
      case 'vitals':
        setIsVitalsOpen(true);
        break;
      case 'assign':
        setIsAssignDoctorOpen(true);
        break;
      case 'prescription':
        setIsPrescriptionOpen(true);
        break;
    }
  };

  // Filtrer les patients selon le rôle
  const getPatientActions = (patient: Patient) => {
    if (user?.role === 'nurse') {
      return (
        <div className="flex gap-2">
          <Button 
            variant="outline" 
            size="sm"
            onClick={() => handlePatientAction(patient, 'vitals')}
          >
            <Activity className="w-3 h-3 mr-1" />
            Paramètres vitaux
          </Button>
          {!patient.assignedDoctor && (
            <Button 
              variant="outline" 
              size="sm"
              onClick={() => handlePatientAction(patient, 'assign')}
            >
              <UserCheck className="w-3 h-3 mr-1" />
              Assigner médecin
            </Button>
          )}
        </div>
      );
    }

    if (user?.role === 'doctor') {
      // Afficher seulement les patients assignés au médecin connecté
      return (
        <div className="flex gap-2">
          <Button variant="outline" size="sm">
            <FileText className="w-3 h-3 mr-1" />
            Dossier
          </Button>
          <Button 
            variant="outline" 
            size="sm"
            onClick={() => handlePatientAction(patient, 'prescription')}
          >
            <Stethoscope className="w-3 h-3 mr-1" />
            Ordonnance
          </Button>
        </div>
      );
    }

    return (
      <div className="flex gap-2">
        <Button variant="outline" size="sm">
          <FileText className="w-3 h-3 mr-1" />
          Dossier
        </Button>
        <Button variant="outline" size="sm">
          <Calendar className="w-3 h-3 mr-1" />
          RDV
        </Button>
      </div>
    );
  };

  const getPatientList = () => {
    if (user?.role === 'doctor') {
      // Filtrer pour ne montrer que les patients assignés au médecin
      return filteredPatients.filter(patient => patient.assignedDoctor === `Dr. ${user.lastName}`);
    }
    return filteredPatients;
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-gray-900">
          {user?.role === 'nurse' ? 'Accueil des patients' : 
           user?.role === 'doctor' ? 'Mes patients' : 
           'Gestion des patients'}
        </h2>
        {user?.role === 'nurse' && (
          <Button 
            className="medical-button"
            onClick={() => setIsNewPatientOpen(true)}
          >
            <Plus className="w-4 h-4 mr-2" />
            Nouveau patient
          </Button>
        )}
      </div>

      <Card className="medical-card">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>
              {user?.role === 'nurse' ? 'Patients à accueillir' : 
               user?.role === 'doctor' ? 'Patients assignés' : 
               'Liste des patients'}
            </CardTitle>
            <div className="relative w-64">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input
                placeholder="Rechercher un patient..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {getPatientList().map((patient) => (
              <div 
                key={patient.id}
                className="flex items-center gap-4 p-4 rounded-lg border border-gray-200 hover:shadow-md transition-all cursor-pointer"
              >
                <Avatar className="w-12 h-12">
                  <AvatarFallback className="bg-medical-100 text-medical-700">
                    {patient.firstName[0]}{patient.lastName[0]}
                  </AvatarFallback>
                </Avatar>
                
                <div className="flex-1 grid grid-cols-1 md:grid-cols-4 gap-4">
                  <div>
                    <p className="font-medium text-gray-900">
                      {patient.firstName} {patient.lastName}
                    </p>
                    <p className="text-sm text-gray-500">
                      {getAge(patient.dateOfBirth)} ans
                    </p>
                  </div>
                  
                  <div className="space-y-1">
                    <p className="text-sm text-gray-600 flex items-center gap-1">
                      <Mail className="w-3 h-3" />
                      {patient.email}
                    </p>
                    <p className="text-sm text-gray-600 flex items-center gap-1">
                      <Phone className="w-3 h-3" />
                      {patient.phone}
                    </p>
                  </div>
                  
                  <div className="space-y-1">
                    <p className="text-sm text-gray-600 flex items-center gap-1">
                      <Calendar className="w-3 h-3" />
                      Dernière visite: {new Date(patient.lastVisit).toLocaleDateString('fr-FR')}
                    </p>
                    <p className="text-sm text-gray-600">
                      Condition: {patient.condition}
                    </p>
                    {patient.assignedDoctor && (
                      <p className="text-sm text-medical-600 font-medium">
                        Assigné à: {patient.assignedDoctor}
                      </p>
                    )}
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <Badge className={`status-badge ${getStatusColor(patient.status)}`}>
                      {patient.status}
                    </Badge>
                    {getPatientActions(patient)}
                  </div>
                </div>
              </div>
            ))}
            
            {getPatientList().length === 0 && (
              <div className="text-center py-8 text-gray-500">
                <Search className="w-12 h-12 mx-auto mb-3 text-gray-300" />
                <p>
                  {user?.role === 'doctor' ? 'Aucun patient assigné' : 'Aucun patient trouvé'}
                </p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      <NewPatientModal
        isOpen={isNewPatientOpen}
        onClose={() => setIsNewPatientOpen(false)}
        onSave={(patient) => console.log('Nouveau patient:', patient)}
      />

      {selectedPatient && (
        <>
          <PatientVitalsModal
            isOpen={isVitalsOpen}
            onClose={() => setIsVitalsOpen(false)}
            patientName={`${selectedPatient.firstName} ${selectedPatient.lastName}`}
            onSave={(vitals) => console.log('Paramètres vitaux:', vitals)}
          />

          <AssignDoctorModal
            isOpen={isAssignDoctorOpen}
            onClose={() => setIsAssignDoctorOpen(false)}
            patientName={`${selectedPatient.firstName} ${selectedPatient.lastName}`}
            onAssign={(doctorId) => console.log('Patient assigné au médecin:', doctorId)}
          />

          <PrescriptionModal
            isOpen={isPrescriptionOpen}
            onClose={() => setIsPrescriptionOpen(false)}
            patientName={`${selectedPatient.firstName} ${selectedPatient.lastName}`}
            onSave={(prescription) => console.log('Ordonnance créée:', prescription)}
          />
        </>
      )}
    </div>
  );
};

export default PatientsList;
