
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { 
  FileText, 
  Upload, 
  Search, 
  Calendar,
  User,
  Activity,
  Heart,
  Pill,
  TestTube,
  Image,
  Plus
} from 'lucide-react';
import { UserRole } from '@/contexts/AuthContext';
import DocumentViewModal from '@/components/modals/DocumentViewModal';
import DocumentCard from './DocumentCard';

interface MedicalRecordsProps {
  userRole: UserRole;
}

const MedicalRecords: React.FC<MedicalRecordsProps> = ({ userRole }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [viewingDoc, setViewingDoc] = useState<any>(null);

  const categories = [
    { id: 'all', label: 'Tous les documents', icon: FileText },
    { id: 'consultations', label: 'Consultations', icon: User },
    { id: 'prescriptions', label: 'Ordonnances', icon: Pill },
    { id: 'analyses', label: 'Analyses', icon: TestTube },
    { id: 'imaging', label: 'Imagerie', icon: Image },
    { id: 'reports', label: 'Rapports', icon: Activity }
  ];

  const documents = [
    {
      id: '1',
      title: 'Consultation cardiologique',
      type: 'consultations',
      date: '2024-01-15',
      doctor: 'Dr. Mbarga',
      category: 'Cardiologie',
      status: 'completed',
      fileType: 'PDF',
      size: '2.3 MB',
      content: 'Consultation cardiologique complète. Patient en bonne santé générale. Tension artérielle normale. Rythme cardiaque régulier.'
    },
    {
      id: '2',
      title: 'Ordonnance - Traitement hypertension',
      type: 'prescriptions',
      date: '2024-01-10',
      doctor: 'Dr. Mbarga',
      category: 'Cardiologie',
      status: 'active',
      fileType: 'PDF',
      size: '856 KB',
      content: 'Prescription pour traitement de l\'hypertension. Lisinopril 10mg une fois par jour le matin.'
    }
  ];

  const filteredDocuments = documents.filter(doc => {
    const matchesSearch = doc.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         doc.doctor.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         doc.category.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || doc.type === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const handleView = (doc: any) => {
    setViewingDoc(doc);
  };

  const handleDownload = (doc: any) => {
    console.log('Téléchargement:', doc.title);
    alert(`Téléchargement de "${doc.title}" démarré!`);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">
            {userRole === 'patient' ? 'Mon dossier médical' : 'Dossiers médicaux'}
          </h2>
          <p className="text-gray-600">
            {userRole === 'patient' 
              ? 'Consultez et gérez vos documents médicaux'
              : 'Gérez les dossiers médicaux de vos patients'
            }
          </p>
        </div>
        
        {userRole !== 'patient' && (
          <Button className="medical-button">
            <Plus className="w-4 h-4 mr-2" />
            Nouveau document
          </Button>
        )}
      </div>

      <div className="flex flex-col lg:flex-row gap-4">
        <div className="flex-1">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
            <Input
              placeholder="Rechercher dans les documents..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
        </div>
        
        <div className="flex gap-2 overflow-x-auto pb-2">
          {categories.map((category) => (
            <Button
              key={category.id}
              variant={selectedCategory === category.id ? "default" : "outline"}
              size="sm"
              onClick={() => setSelectedCategory(category.id)}
              className="whitespace-nowrap"
            >
              <category.icon className="w-4 h-4 mr-2" />
              {category.label}
            </Button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 gap-4">
        {filteredDocuments.map((doc) => (
          <DocumentCard
            key={doc.id}
            document={doc}
            onView={handleView}
            onDownload={handleDownload}
          />
        ))}
      </div>

      {filteredDocuments.length === 0 && (
        <Card className="medical-card">
          <CardContent className="p-12 text-center">
            <FileText className="w-12 h-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">
              Aucun document trouvé
            </h3>
            <p className="text-gray-600">
              {searchTerm || selectedCategory !== 'all'
                ? 'Essayez de modifier vos critères de recherche'
                : 'Aucun document médical disponible pour le moment'
              }
            </p>
          </CardContent>
        </Card>
      )}

      {userRole === 'patient' && (
        <Card className="medical-card bg-medical-50 border-medical-200">
          <CardHeader>
            <CardTitle className="text-lg">Actions rapides</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <Button variant="outline" className="h-auto p-4 flex flex-col items-center gap-2">
                <Upload className="w-6 h-6 text-medical-600" />
                <span>Téléverser un document</span>
              </Button>
              <Button variant="outline" className="h-auto p-4 flex flex-col items-center gap-2">
                <Calendar className="w-6 h-6 text-medical-600" />
                <span>Demander un RDV</span>
              </Button>
              <Button variant="outline" className="h-auto p-4 flex flex-col items-center gap-2">
                <Heart className="w-6 h-6 text-medical-600" />
                <span>Carnet de santé</span>
              </Button>
              <Button variant="outline" className="h-auto p-4 flex flex-col items-center gap-2">
                <Activity className="w-6 h-6 text-medical-600" />
                <span>Suivi médical</span>
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {viewingDoc && (
        <DocumentViewModal
          isOpen={!!viewingDoc}
          onClose={() => setViewingDoc(null)}
          document={viewingDoc}
        />
      )}
    </div>
  );
};

export default MedicalRecords;
