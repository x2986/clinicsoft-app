
import React, { useState } from 'react';
import { UserRole } from '@/contexts/AuthContext';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  Calendar, 
  Clock, 
  User, 
  Plus,
  Edit,
  Trash2,
  CheckCircle,
  XCircle
} from 'lucide-react';

interface ScheduleEvent {
  id: string;
  title: string;
  patient?: string;
  type: 'consultation' | 'surgery' | 'meeting' | 'break';
  startTime: string;
  endTime: string;
  status: 'scheduled' | 'completed' | 'cancelled';
  room?: string;
}

interface ScheduleSectionProps {
  userRole: UserRole;
}

const ScheduleSection: React.FC<ScheduleSectionProps> = ({ userRole }) => {
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);
  const [viewMode, setViewMode] = useState<'day' | 'week'>('day');

  const mockEvents: ScheduleEvent[] = [
    {
      id: '1',
      title: 'Consultation cardiologique',
      patient: 'Jean Dupont',
      type: 'consultation',
      startTime: '09:00',
      endTime: '09:30',
      status: 'scheduled',
      room: 'Salle 101'
    },
    {
      id: '2',
      title: 'Contrôle post-opératoire',
      patient: 'Marie Martin',
      type: 'consultation',
      startTime: '10:00',
      endTime: '10:30',
      status: 'completed',
      room: 'Salle 102'
    },
    {
      id: '3',
      title: 'Chirurgie programmée',
      patient: 'Pierre Dubois',
      type: 'surgery',
      startTime: '14:00',
      endTime: '16:00',
      status: 'scheduled',
      room: 'Bloc 1'
    },
    {
      id: '4',
      title: 'Pause déjeuner',
      type: 'break',
      startTime: '12:00',
      endTime: '13:30',
      status: 'scheduled'
    }
  ];

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'consultation': return 'bg-blue-100 text-blue-800';
      case 'surgery': return 'bg-red-100 text-red-800';
      case 'meeting': return 'bg-purple-100 text-purple-800';
      case 'break': return 'bg-gray-100 text-gray-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getTypeText = (type: string) => {
    switch (type) {
      case 'consultation': return 'Consultation';
      case 'surgery': return 'Chirurgie';
      case 'meeting': return 'Réunion';
      case 'break': return 'Pause';
      default: return type;
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed': return <CheckCircle className="w-4 h-4 text-green-600" />;
      case 'cancelled': return <XCircle className="w-4 h-4 text-red-600" />;
      default: return <Clock className="w-4 h-4 text-blue-600" />;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Planning</h2>
          <p className="text-gray-600">
            {userRole === 'doctor' ? 'Gérez votre emploi du temps' : 
             userRole === 'nurse' ? 'Votre planning de soins' :
             'Planning de l\'équipe médicale'}
          </p>
        </div>
        {(userRole === 'doctor' || userRole === 'nurse') && (
          <Button className="bg-medical-500 hover:bg-medical-600">
            <Plus className="w-4 h-4 mr-2" />
            Nouveau créneau
          </Button>
        )}
      </div>

      {/* Contrôles de navigation */}
      <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between">
        <div className="flex items-center gap-4">
          <input
            type="date"
            value={selectedDate}
            onChange={(e) => setSelectedDate(e.target.value)}
            className="px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-medical-500"
          />
          <div className="flex border border-gray-300 rounded-md">
            <button
              onClick={() => setViewMode('day')}
              className={`px-3 py-2 text-sm font-medium rounded-l-md ${
                viewMode === 'day' ? 'bg-medical-500 text-white' : 'bg-white text-gray-700 hover:bg-gray-50'
              }`}
            >
              Jour
            </button>
            <button
              onClick={() => setViewMode('week')}
              className={`px-3 py-2 text-sm font-medium rounded-r-md border-l ${
                viewMode === 'week' ? 'bg-medical-500 text-white' : 'bg-white text-gray-700 hover:bg-gray-50'
              }`}
            >
              Semaine
            </button>
          </div>
        </div>

        <div className="text-sm text-gray-600">
          {new Date(selectedDate).toLocaleDateString('fr-FR', {
            weekday: 'long',
            year: 'numeric',
            month: 'long',
            day: 'numeric'
          })}
        </div>
      </div>

      {/* Planning */}
      <div className="grid gap-4">
        {mockEvents.map((event) => (
          <Card key={event.id} className="medical-card">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="flex items-center gap-2">
                    {getStatusIcon(event.status)}
                    <div>
                      <h3 className="font-semibold text-gray-900">{event.title}</h3>
                      {event.patient && (
                        <div className="flex items-center gap-1 text-sm text-gray-600 mt-1">
                          <User className="w-4 h-4" />
                          <span>{event.patient}</span>
                        </div>
                      )}
                    </div>
                  </div>
                  <div className="flex flex-col sm:flex-row gap-2">
                    <Badge className={getTypeColor(event.type)}>
                      {getTypeText(event.type)}
                    </Badge>
                    {event.room && (
                      <Badge variant="outline">
                        {event.room}
                      </Badge>
                    )}
                  </div>
                </div>
                
                <div className="flex items-center gap-4">
                  <div className="text-right">
                    <div className="font-medium text-gray-900">
                      {event.startTime} - {event.endTime}
                    </div>
                    <div className="text-sm text-gray-600">
                      {event.status === 'completed' ? 'Terminé' : 
                       event.status === 'cancelled' ? 'Annulé' : 'Programmé'}
                    </div>
                  </div>
                  
                  {(userRole === 'doctor' || userRole === 'nurse') && event.status === 'scheduled' && (
                    <div className="flex gap-2">
                      <Button size="sm" variant="outline">
                        <Edit className="w-4 h-4" />
                      </Button>
                      <Button size="sm" variant="outline" className="text-red-600 hover:text-red-700">
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {mockEvents.length === 0 && (
        <div className="text-center py-12">
          <Calendar className="w-12 h-12 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">Aucun événement prévu</h3>
          <p className="text-gray-600">Votre planning est libre pour cette journée.</p>
        </div>
      )}
    </div>
  );
};

export default ScheduleSection;
