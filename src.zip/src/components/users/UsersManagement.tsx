
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { 
  Users, 
  UserPlus, 
  Search, 
  Mail, 
  Phone,
  Edit,
  Trash2,
  MoreHorizontal,
  Shield,
  User,
  Stethoscope
} from 'lucide-react';
import AddUserModal from '@/components/modals/AddUserModal';

const UsersManagement = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedRole, setSelectedRole] = useState('all');
  const [isAddUserOpen, setIsAddUserOpen] = useState(false);

  const users = [
    {
      id: '1',
      firstName: 'Dr. Sarah',
      lastName: 'Martin',
      email: 'sarah.martin@hospital.fr',
      phone: '+33 1 23 45 67 89',
      role: 'doctor',
      speciality: 'Cardiologie',
      status: 'active',
      lastLogin: '2024-06-26 14:30',
      patients: 156
    },
    {
      id: '2',
      firstName: 'Marie',
      lastName: 'Dubois',
      email: 'marie.dubois@hospital.fr',
      phone: '+33 1 23 45 67 90',
      role: 'nurse',
      speciality: 'Soins intensifs',
      status: 'active',
      lastLogin: '2024-06-26 16:45',
      patients: 45
    },
    {
      id: '3',
      firstName: 'Pierre',
      lastName: 'Admin',
      email: 'pierre.admin@hospital.fr',
      phone: '+33 1 23 45 67 91',
      role: 'admin',
      speciality: null,
      status: 'active',
      lastLogin: '2024-06-26 09:15',
      patients: 0
    }
  ];

  const filteredUsers = users.filter(user => {
    const matchesSearch = `${user.firstName} ${user.lastName}`.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         user.email.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesRole = selectedRole === 'all' || user.role === selectedRole;
    return matchesSearch && matchesRole;
  });

  const getRoleIcon = (role: string) => {
    switch (role) {
      case 'doctor': return Stethoscope;
      case 'nurse': return User;
      case 'admin': return Shield;
      default: return User;
    }
  };

  const getRoleColor = (role: string) => {
    switch (role) {
      case 'doctor': return 'bg-blue-100 text-blue-800';
      case 'nurse': return 'bg-green-100 text-green-800';
      case 'admin': return 'bg-purple-100 text-purple-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getRoleLabel = (role: string) => {
    switch (role) {
      case 'doctor': return 'Médecin';
      case 'nurse': return 'Infirmier';
      case 'admin': return 'Administrateur';
      default: return role;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'bg-green-100 text-green-800';
      case 'inactive': return 'bg-red-100 text-red-800';
      case 'pending': return 'bg-yellow-100 text-yellow-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const stats = [
    { label: 'Total utilisateurs', value: users.length.toString(), color: 'text-blue-600' },
    { label: 'Médecins', value: users.filter(u => u.role === 'doctor').length.toString(), color: 'text-blue-600' },
    { label: 'Infirmiers', value: users.filter(u => u.role === 'nurse').length.toString(), color: 'text-green-600' },
    { label: 'Administrateurs', value: users.filter(u => u.role === 'admin').length.toString(), color: 'text-purple-600' }
  ];

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Gestion des utilisateurs</h2>
          <p className="text-gray-600">Gérez les comptes utilisateurs de votre établissement</p>
        </div>
        <Button 
          onClick={() => setIsAddUserOpen(true)}
          className="bg-medical-500 hover:bg-medical-600"
        >
          <UserPlus className="w-4 h-4 mr-2" />
          Nouvel utilisateur
        </Button>
      </div>

      {/* Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, index) => (
          <Card key={index} className="medical-card">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">{stat.label}</p>
                  <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
                </div>
                <Users className={`w-8 h-8 ${stat.color}`} />
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Filters */}
      <div className="flex flex-col lg:flex-row gap-4">
        <div className="flex-1">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
            <Input
              placeholder="Rechercher un utilisateur..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
        </div>
        <div>
          <select
            value={selectedRole}
            onChange={(e) => setSelectedRole(e.target.value)}
            className="px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-medical-500"
          >
            <option value="all">Tous les rôles</option>
            <option value="doctor">Médecins</option>
            <option value="nurse">Infirmiers</option>
            <option value="admin">Administrateurs</option>
          </select>
        </div>
      </div>

      {/* Users list */}
      <div className="grid grid-cols-1 gap-4">
        {filteredUsers.map((user) => {
          const RoleIcon = getRoleIcon(user.role);
          
          return (
            <Card key={user.id} className="medical-card hover:shadow-md transition-shadow">
              <CardContent className="p-6">
                <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
                  <div className="flex-1">
                    <div className="flex items-start gap-4">
                      <div className="w-12 h-12 bg-medical-100 rounded-full flex items-center justify-center flex-shrink-0">
                        <RoleIcon className="w-6 h-6 text-medical-600" />
                      </div>
                      
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-3 mb-2">
                          <h3 className="text-lg font-medium text-gray-900">
                            {user.firstName} {user.lastName}
                          </h3>
                          <Badge className={getRoleColor(user.role)}>
                            {getRoleLabel(user.role)}
                          </Badge>
                          <Badge className={getStatusColor(user.status)}>
                            {user.status === 'active' ? 'Actif' : 'Inactif'}
                          </Badge>
                        </div>
                        
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm text-gray-600">
                          <div className="space-y-1">
                            <div className="flex items-center gap-2">
                              <Mail className="w-4 h-4" />
                              <span>{user.email}</span>
                            </div>
                            <div className="flex items-center gap-2">
                              <Phone className="w-4 h-4" />
                              <span>{user.phone}</span>
                            </div>
                          </div>
                          <div className="space-y-1">
                            {user.speciality && (
                              <div>
                                <span className="font-medium">Spécialité:</span> {user.speciality}
                              </div>
                            )}
                            {user.role !== 'admin' && (
                              <div>
                                <span className="font-medium">Patients:</span> {user.patients}
                              </div>
                            )}
                            <div>
                              <span className="font-medium">Dernière connexion:</span> {new Date(user.lastLogin).toLocaleString('fr-FR')}
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-2">
                    <Button variant="outline" size="sm">
                      <Edit className="w-4 h-4 mr-2" />
                      Modifier
                    </Button>
                    <Button variant="outline" size="sm" className="text-red-600 hover:text-red-700">
                      <Trash2 className="w-4 h-4 mr-2" />
                      Supprimer
                    </Button>
                    <Button variant="outline" size="sm">
                      <MoreHorizontal className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {filteredUsers.length === 0 && (
        <Card className="medical-card">
          <CardContent className="p-12 text-center">
            <Users className="w-12 h-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">
              Aucun utilisateur trouvé
            </h3>
            <p className="text-gray-600">
              Essayez de modifier vos critères de recherche
            </p>
          </CardContent>
        </Card>
      )}

      <AddUserModal
        isOpen={isAddUserOpen}
        onClose={() => setIsAddUserOpen(false)}
      />
    </div>
  );
};

export default UsersManagement;
