
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Clock, User, Calendar, FileText } from 'lucide-react';
import { UserRole } from '@/contexts/AuthContext';

interface ActivityProps {
  userRole: UserRole;
}

const RecentActivity: React.FC<ActivityProps> = ({ userRole }) => {
  const getActivities = (role: UserRole) => {
    switch (role) {
      case 'patient':
        return [
          {
            id: 1,
            type: 'appointment',
            title: 'Consultation avec Dr. Martin',
            description: 'Cardiologie - Contrôle de routine',
            time: '10:30',
            status: 'confirmed',
            avatar: 'DM'
          },
          {
            id: 2,
            type: 'message',
            title: 'Nouveau message',
            description: 'Dr. Durand a répondu à votre question',
            time: '09:15',
            status: 'new',
            avatar: 'DD'
          },
          {
            id: 3,
            type: 'prescription',
            title: 'Nouvelle ordonnance',
            description: 'Ordonnance électronique disponible',
            time: '08:45',
            status: 'ready',
            avatar: 'Rx'
          }
        ];
      case 'doctor':
        return [
          {
            id: 1,
            type: 'appointment',
            title: 'Pierre Dupont',
            description: 'Consultation de suivi - Hypertension',
            time: '14:30',
            status: 'upcoming',
            avatar: 'PD'
          },
          {
            id: 2,
            type: 'appointment',
            title: 'Marie Leroy',
            description: 'Première consultation - Cardiologie',
            time: '15:00',
            status: 'upcoming',
            avatar: 'ML'
          },
          {
            id: 3,
            type: 'message',
            title: 'Message urgent',
            description: 'Patient signale des symptômes',
            time: '13:20',
            status: 'urgent',
            avatar: 'JM'
          }
        ];
      case 'nurse':
        return [
          {
            id: 1,
            type: 'task',
            title: 'Prise de tension',
            description: 'M. Martin - Chambre 205',
            time: '16:00',
            status: 'pending',
            avatar: 'MT'
          },
          {
            id: 2,
            type: 'report',
            title: 'Rapport de soins',
            description: 'Mme Dubois - Soins post-opératoires',
            time: '15:30',
            status: 'completed',
            avatar: 'AD'
          }
        ];
      case 'admin':
        return [
          {
            id: 1,
            type: 'user',
            title: 'Nouvel utilisateur',
            description: 'Dr. Sophie Benoit - Dermatologue',
            time: '11:30',
            status: 'pending',
            avatar: 'SB'
          },
          {
            id: 2,
            type: 'system',
            title: 'Mise à jour système',
            description: 'Maintenance programmée ce soir',
            time: '10:00',
            status: 'scheduled',
            avatar: 'SY'
          }
        ];
      default:
        return [];
    }
  };

  const activities = getActivities(userRole);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'confirmed':
      case 'completed':
        return 'bg-green-100 text-green-800';
      case 'urgent':
        return 'bg-red-100 text-red-800';
      case 'new':
      case 'ready':
        return 'bg-blue-100 text-blue-800';
      case 'pending':
      case 'upcoming':
        return 'bg-yellow-100 text-yellow-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getIcon = (type: string) => {
    switch (type) {
      case 'appointment':
        return <Calendar className="w-4 h-4" />;
      case 'message':
        return <User className="w-4 h-4" />;
      case 'prescription':
      case 'report':
        return <FileText className="w-4 h-4" />;
      default:
        return <Clock className="w-4 h-4" />;
    }
  };

  return (
    <Card className="medical-card">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Clock className="w-5 h-5 text-medical-500" />
          Activité récente
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {activities.map((activity) => (
            <div key={activity.id} className="flex items-center gap-4 p-3 rounded-lg hover:bg-gray-50 transition-colors">
              <Avatar className="w-10 h-10">
                <AvatarFallback className="bg-medical-100 text-medical-700">
                  {activity.avatar}
                </AvatarFallback>
              </Avatar>
              
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1">
                  {getIcon(activity.type)}
                  <p className="text-sm font-medium text-gray-900 truncate">
                    {activity.title}
                  </p>
                </div>
                <p className="text-xs text-gray-500 truncate">
                  {activity.description}
                </p>
              </div>
              
              <div className="flex items-center gap-2">
                <Badge className={`status-badge ${getStatusColor(activity.status)}`}>
                  {activity.status}
                </Badge>
                <span className="text-xs text-gray-400">{activity.time}</span>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};

export default RecentActivity;
