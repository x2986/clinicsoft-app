
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Users, Calendar, TrendingUp, Activity, Hospital, UserCheck } from 'lucide-react';

const AdminDashboard = () => {
  const hospitalStats = {
    totalPatients: 247,
    todayAppointments: 32,
    monthlyRevenue: 850000, // FCFA
    activeDoctors: 18,
    activeNurses: 12,
    occupancyRate: 85
  };

  const recentActivities = [
    {
      id: 1,
      type: 'user',
      title: 'Nouveau médecin',
      description: 'Dr. Mbeki Sophie - Pédiatre',
      time: '11:30',
      status: 'pending'
    },
    {
      id: 2,
      type: 'appointment',
      title: 'Pic de consultations',
      description: '45 rendez-vous programmés aujourd\'hui',
      time: '10:00',
      status: 'info'
    },
    {
      id: 3,
      type: 'system',
      title: 'Maintenance programmée',
      description: 'Mise à jour système ce soir 22h-24h',
      time: '09:15',
      status: 'scheduled'
    }
  ];

  const departmentStats = [
    { name: 'Cardiologie', patients: 45, revenue: 150000 },
    { name: 'Pédiatrie', patients: 62, revenue: 120000 },
    { name: 'Dermatologie', patients: 38, revenue: 95000 },
    { name: 'Médecine générale', patients: 89, revenue: 200000 }
  ];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Tableau de bord Administrateur</h1>
        <p className="text-gray-600 mt-1">Vue d'ensemble de l'établissement de santé</p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-6 gap-6">
        <Card className="medical-card">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total patients</CardTitle>
            <Users className="h-4 w-4 text-medical-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{hospitalStats.totalPatients}</div>
            <p className="text-xs text-gray-500">+12 ce mois</p>
          </CardContent>
        </Card>

        <Card className="medical-card">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">RDV aujourd'hui</CardTitle>
            <Calendar className="h-4 w-4 text-medical-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{hospitalStats.todayAppointments}</div>
            <p className="text-xs text-gray-500">+8% vs hier</p>
          </CardContent>
        </Card>

        <Card className="medical-card">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Revenus mensuels</CardTitle>
            <TrendingUp className="h-4 w-4 text-medical-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{hospitalStats.monthlyRevenue.toLocaleString()} F</div>
            <p className="text-xs text-gray-500">+15% ce mois</p>
          </CardContent>
        </Card>

        <Card className="medical-card">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Médecins actifs</CardTitle>
            <Activity className="h-4 w-4 text-medical-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{hospitalStats.activeDoctors}</div>
            <p className="text-xs text-gray-500">Sur 20 total</p>
          </CardContent>
        </Card>

        <Card className="medical-card">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Infirmières</CardTitle>
            <UserCheck className="h-4 w-4 text-medical-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{hospitalStats.activeNurses}</div>
            <p className="text-xs text-gray-500">En service</p>
          </CardContent>
        </Card>

        <Card className="medical-card">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Occupation</CardTitle>
            <Hospital className="h-4 w-4 text-medical-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{hospitalStats.occupancyRate}%</div>
            <p className="text-xs text-gray-500">Taux d'occupation</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Activities */}
        <Card className="medical-card">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Activity className="w-5 h-5 text-medical-500" />
              Activités récentes
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {recentActivities.map((activity) => (
                <div key={activity.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <p className="font-medium text-gray-900">{activity.title}</p>
                      <Badge variant={
                        activity.status === 'pending' ? 'secondary' : 
                        activity.status === 'info' ? 'default' : 'outline'
                      }>
                        {activity.status === 'pending' ? 'En attente' : 
                         activity.status === 'info' ? 'Info' : 'Programmé'}
                      </Badge>
                    </div>
                    <p className="text-sm text-gray-600">{activity.description}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-xs text-gray-500">{activity.time}</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Department Performance */}
        <Card className="medical-card">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Hospital className="w-5 h-5 text-medical-500" />
              Performance par service
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {departmentStats.map((dept, index) => (
                <div key={index} className="p-3 bg-gray-50 rounded-lg">
                  <div className="flex justify-between items-start mb-2">
                    <p className="font-medium text-gray-900">{dept.name}</p>
                    <p className="text-sm font-medium text-medical-600">
                      {dept.revenue.toLocaleString()} FCFA
                    </p>
                  </div>
                  <div className="flex justify-between items-center">
                    <p className="text-sm text-gray-600">{dept.patients} patients</p>
                    <div className="flex items-center gap-2">
                      <div className="w-12 bg-gray-200 rounded-full h-2">
                        <div 
                          className="bg-medical-500 h-2 rounded-full" 
                          style={{ width: `${(dept.patients / 100) * 100}%` }}
                        ></div>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default AdminDashboard;
