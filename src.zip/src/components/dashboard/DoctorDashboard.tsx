
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Users, Calendar, FileText, Activity, Clock, Stethoscope } from 'lucide-react';

const DoctorDashboard = () => {
  const todayPatients = [
    {
      id: 1,
      name: 'Nkomo Jean',
      time: '09:00',
      type: 'Consultation',
      status: 'waiting',
      vitals: { tension: '120/80', temperature: '37.2°C' }
    },
    {
      id: 2,
      name: 'Mballa Marie',
      time: '10:30',
      type: 'Suivi',
      status: 'in-progress',
      vitals: { tension: '130/85', temperature: '36.8°C' }
    },
    {
      id: 3,
      name: 'Fouda Paul',
      time: '11:15',
      type: 'Urgence',
      status: 'completed',
      vitals: { tension: '140/90', temperature: '38.1°C' }
    }
  ];

  const assignedPatients = [
    { name: 'Nkomo Jean', assignedBy: 'Inf. Mbeki', time: '08:30', priority: 'normal' },
    { name: 'Biya Marie', assignedBy: 'Inf. Essomba', time: '09:15', priority: 'urgent' },
    { name: 'Ahidjo Paul', assignedBy: 'Inf. Mbeki', time: '10:00', priority: 'normal' }
  ];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Tableau de bord Médecin</h1>
        <p className="text-gray-600 mt-1">Gérez vos patients et consultations</p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card className="medical-card">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Patients aujourd'hui</CardTitle>
            <Users className="h-4 w-4 text-medical-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">8</div>
            <p className="text-xs text-gray-500">3 en attente</p>
          </CardContent>
        </Card>

        <Card className="medical-card">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Consultations</CardTitle>
            <Activity className="h-4 w-4 text-medical-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">156</div>
            <p className="text-xs text-gray-500">Ce mois</p>
          </CardContent>
        </Card>

        <Card className="medical-card">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Ordonnances</CardTitle>
            <FileText className="h-4 w-4 text-medical-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">42</div>
            <p className="text-xs text-gray-500">Cette semaine</p>
          </CardContent>
        </Card>

        <Card className="medical-card">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Patients assignés</CardTitle>
            <Stethoscope className="h-4 w-4 text-medical-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">3</div>
            <p className="text-xs text-gray-500">Nouveaux</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Today's Schedule */}
        <Card className="medical-card">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Calendar className="w-5 h-5 text-medical-500" />
              Planning d'aujourd'hui
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {todayPatients.map((patient) => (
                <div key={patient.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <p className="font-medium text-gray-900">{patient.name}</p>
                      <Badge variant={
                        patient.status === 'waiting' ? 'secondary' : 
                        patient.status === 'in-progress' ? 'default' : 'outline'
                      }>
                        {patient.status === 'waiting' ? 'En attente' : 
                         patient.status === 'in-progress' ? 'En cours' : 'Terminé'}
                      </Badge>
                    </div>
                    <p className="text-sm text-gray-600">{patient.type}</p>
                    <p className="text-xs text-gray-500">
                      Tension: {patient.vitals.tension} | Temp: {patient.vitals.temperature}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-medium">{patient.time}</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Assigned Patients */}
        <Card className="medical-card">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Users className="w-5 h-5 text-medical-500" />
              Patients assignés par l'infirmière
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {assignedPatients.map((patient, index) => (
                <div key={index} className="p-3 bg-gray-50 rounded-lg">
                  <div className="flex justify-between items-start mb-2">
                    <p className="font-medium text-gray-900">{patient.name}</p>
                    <Badge variant={patient.priority === 'urgent' ? 'destructive' : 'secondary'}>
                      {patient.priority === 'urgent' ? 'Urgent' : 'Normal'}
                    </Badge>
                  </div>
                  <p className="text-sm text-gray-600">Assigné par: {patient.assignedBy}</p>
                  <p className="text-xs text-gray-500">Heure: {patient.time}</p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default DoctorDashboard;
