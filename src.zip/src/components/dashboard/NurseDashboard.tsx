
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Users, Activity, FileText, Clock, Thermometer, Heart } from 'lucide-react';

const NurseDashboard = () => {
  const todayTasks = [
    {
      id: 1,
      patient: 'Nkomo Jean',
      task: 'Prise de tension',
      time: '08:00',
      status: 'completed',
      room: 'Salle 1'
    },
    {
      id: 2,
      patient: 'Mballa Marie',
      task: 'Paramètres vitaux',
      time: '09:30',
      status: 'pending',
      room: 'Salle 2'
    },
    {
      id: 3,
      patient: 'Fouda Paul',
      task: 'Préparation consultation',
      time: '10:15',
      status: 'in-progress',
      room: 'Salle 3'
    }
  ];

  const waitingPatients = [
    {
      name: 'Biya Marie',
      arrivalTime: '08:45',
      reason: 'Consultation générale',
      priority: 'normal',
      vitalsRecorded: false
    },
    {
      name: 'Ahidjo Paul',
      arrivalTime: '09:15',
      reason: 'Urgence',
      priority: 'urgent',
      vitalsRecorded: false
    },
    {
      name: 'Mvondo Jean',
      arrivalTime: '09:30',
      reason: 'Suivi',
      priority: 'normal',
      vitalsRecorded: true
    }
  ];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Tableau de bord Infirmière</h1>
        <p className="text-gray-600 mt-1">Gérez l'accueil et les soins aux patients</p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card className="medical-card">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Patients en attente</CardTitle>
            <Users className="h-4 w-4 text-medical-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">3</div>
            <p className="text-xs text-gray-500">1 urgent</p>
          </CardContent>
        </Card>

        <Card className="medical-card">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Soins aujourd'hui</CardTitle>
            <Activity className="h-4 w-4 text-medical-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">6</div>
            <p className="text-xs text-gray-500">2 en cours</p>
          </CardContent>
        </Card>

        <Card className="medical-card">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Paramètres vitaux</CardTitle>
            <Thermometer className="h-4 w-4 text-medical-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">12</div>
            <p className="text-xs text-gray-500">Enregistrés</p>
          </CardContent>
        </Card>

        <Card className="medical-card">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Patients assignés</CardTitle>
            <Heart className="h-4 w-4 text-medical-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">8</div>
            <p className="text-xs text-gray-500">Aux médecins</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Today's Tasks */}
        <Card className="medical-card">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Activity className="w-5 h-5 text-medical-500" />
              Tâches d'aujourd'hui
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {todayTasks.map((task) => (
                <div key={task.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <p className="font-medium text-gray-900">{task.patient}</p>
                      <Badge variant={
                        task.status === 'completed' ? 'outline' : 
                        task.status === 'in-progress' ? 'default' : 'secondary'
                      }>
                        {task.status === 'completed' ? 'Terminé' : 
                         task.status === 'in-progress' ? 'En cours' : 'En attente'}
                      </Badge>
                    </div>
                    <p className="text-sm text-gray-600">{task.task}</p>
                    <p className="text-xs text-gray-500">{task.room}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-medium">{task.time}</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Waiting Patients */}
        <Card className="medical-card">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Clock className="w-5 h-5 text-medical-500" />
              Patients en attente
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {waitingPatients.map((patient, index) => (
                <div key={index} className="p-3 bg-gray-50 rounded-lg">
                  <div className="flex justify-between items-start mb-2">
                    <div className="flex items-center gap-2">
                      <p className="font-medium text-gray-900">{patient.name}</p>
                      <Badge variant={patient.priority === 'urgent' ? 'destructive' : 'secondary'}>
                        {patient.priority === 'urgent' ? 'Urgent' : 'Normal'}
                      </Badge>
                    </div>
                    <p className="text-xs text-gray-500">{patient.arrivalTime}</p>
                  </div>
                  <p className="text-sm text-gray-600 mb-2">{patient.reason}</p>
                  <div className="flex justify-between items-center">
                    <p className="text-xs text-gray-500">
                      Paramètres: {patient.vitalsRecorded ? '✓ Enregistrés' : '⏳ En attente'}
                    </p>
                    {!patient.vitalsRecorded && (
                      <Button size="sm" variant="outline">
                        Enregistrer paramètres
                      </Button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default NurseDashboard;
