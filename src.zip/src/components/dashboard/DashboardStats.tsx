
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Users, Calendar, FileText, Activity, TrendingUp } from 'lucide-react';
import { UserRole } from '@/contexts/AuthContext';

interface StatsProps {
  userRole: UserRole;
}

const DashboardStats: React.FC<StatsProps> = ({ userRole }) => {
  const getStats = (role: UserRole) => {
    switch (role) {
      case 'patient':
        return [
          { title: 'Prochains RDV', value: '2', icon: Calendar, color: 'text-blue-600' },
          { title: 'Consultations', value: '12', icon: Activity, color: 'text-green-600' },
          { title: 'Ordonnances', value: '5', icon: FileText, color: 'text-purple-600' },
          { title: 'Messages', value: '3', icon: Users, color: 'text-orange-600' },
        ];
      case 'doctor':
        return [
          { title: 'Patients aujourd\'hui', value: '8', icon: Users, color: 'text-blue-600' },
          { title: 'RDV cette semaine', value: '24', icon: Calendar, color: 'text-green-600' },
          { title: 'Consultations', value: '156', icon: Activity, color: 'text-purple-600' },
          { title: 'Revenus ce mois', value: '€3,240', icon: TrendingUp, color: 'text-orange-600' },
        ];
      case 'nurse':
        return [
          { title: 'Patients assignés', value: '15', icon: Users, color: 'text-blue-600' },
          { title: 'Soins aujourd\'hui', value: '6', icon: Activity, color: 'text-green-600' },
          { title: 'Rapports en attente', value: '3', icon: FileText, color: 'text-purple-600' },
          { title: 'Tâches urgentes', value: '2', icon: Calendar, color: 'text-red-600' },
        ];
      case 'admin':
        return [
          { title: 'Total utilisateurs', value: '247', icon: Users, color: 'text-blue-600' },
          { title: 'RDV aujourd\'hui', value: '32', icon: Calendar, color: 'text-green-600' },
          { title: 'Revenus mensuels', value: '€15,680', icon: TrendingUp, color: 'text-purple-600' },
          { title: 'Médecins actifs', value: '18', icon: Activity, color: 'text-orange-600' },
        ];
      default:
        return [];
    }
  };

  const stats = getStats(userRole);

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
      {stats.map((stat, index) => (
        <Card key={index} className="medical-card hover:shadow-lg transition-all duration-300">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">
              {stat.title}
            </CardTitle>
            <stat.icon className={`h-5 w-5 ${stat.color}`} />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-gray-900">{stat.value}</div>
            <div className="flex items-center text-xs text-gray-500 mt-1">
              <TrendingUp className="h-3 w-3 mr-1" />
              +12% ce mois
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
};

export default DashboardStats;
