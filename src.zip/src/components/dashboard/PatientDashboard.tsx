
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Calendar, FileText, Heart, MessageSquare, Pill, Clock } from 'lucide-react';

const PatientDashboard = () => {
  const upcomingAppointments = [
    {
      id: 1,
      doctor: 'Dr. Mballa Jean',
      specialty: 'Cardiologie',
      date: '2024-01-15',
      time: '10:00',
      hospital: 'Hôpital Central de Yaoundé'
    },
    {
      id: 2,
      doctor: 'Dr. Ngono Marie',
      specialty: 'Dermatologie',
      date: '2024-01-18',
      time: '14:30',
      hospital: 'Centre Médical de Douala'
    }
  ];

  const recentPrescriptions = [
    {
      id: 1,
      doctor: 'Dr. Mballa Jean',
      date: '2024-01-10',
      medications: ['Amlodipine 5mg', 'Metformine 500mg'],
      status: 'active'
    },
    {
      id: 2,
      doctor: 'Dr. Fouda Paul',
      date: '2024-01-05',
      medications: ['Paracétamol 500mg', 'Ibuprofène 400mg'],
      status: 'completed'
    }
  ];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Tableau de bord Patient</h1>
        <p className="text-gray-600 mt-1">Gérez vos rendez-vous et suivez votre santé</p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card className="medical-card">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Prochains RDV</CardTitle>
            <Calendar className="h-4 w-4 text-medical-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">2</div>
            <p className="text-xs text-gray-500">Cette semaine</p>
          </CardContent>
        </Card>

        <Card className="medical-card">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Ordonnances</CardTitle>
            <Pill className="h-4 w-4 text-medical-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">5</div>
            <p className="text-xs text-gray-500">Actives</p>
          </CardContent>
        </Card>

        <Card className="medical-card">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Messages</CardTitle>
            <MessageSquare className="h-4 w-4 text-medical-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">3</div>
            <p className="text-xs text-gray-500">Non lus</p>
          </CardContent>
        </Card>

        <Card className="medical-card">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Santé</CardTitle>
            <Heart className="h-4 w-4 text-medical-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">Bon</div>
            <p className="text-xs text-gray-500">État général</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Upcoming Appointments */}
        <Card className="medical-card">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Calendar className="w-5 h-5 text-medical-500" />
              Prochains rendez-vous
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {upcomingAppointments.map((appointment) => (
                <div key={appointment.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div className="flex-1">
                    <p className="font-medium text-gray-900">{appointment.doctor}</p>
                    <p className="text-sm text-gray-600">{appointment.specialty}</p>
                    <p className="text-xs text-gray-500">{appointment.hospital}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-medium">{appointment.date}</p>
                    <p className="text-xs text-gray-500">{appointment.time}</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Recent Prescriptions */}
        <Card className="medical-card">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Pill className="w-5 h-5 text-medical-500" />
              Ordonnances récentes
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {recentPrescriptions.map((prescription) => (
                <div key={prescription.id} className="p-3 bg-gray-50 rounded-lg">
                  <div className="flex justify-between items-start mb-2">
                    <p className="font-medium text-gray-900">{prescription.doctor}</p>
                    <Badge variant={prescription.status === 'active' ? 'default' : 'secondary'}>
                      {prescription.status === 'active' ? 'Active' : 'Terminée'}
                    </Badge>
                  </div>
                  <div className="space-y-1">
                    {prescription.medications.map((med, index) => (
                      <p key={index} className="text-sm text-gray-600">• {med}</p>
                    ))}
                  </div>
                  <p className="text-xs text-gray-500 mt-2">{prescription.date}</p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default PatientDashboard;
