
import React, { useState } from 'react';
import { UserRole } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { 
  Stethoscope, 
  Plus,
  Search
} from 'lucide-react';
import NewAppointmentModal from '@/components/modals/NewAppointmentModal';
import AddUserModal from '@/components/modals/AddUserModal';
import DoctorCard from './DoctorCard';

interface Doctor {
  id: string;
  firstName: string;
  lastName: string;
  speciality: string;
  email: string;
  phone: string;
  patients: number;
  nextAvailability: string;
  status: 'available' | 'busy' | 'offline';
}

interface DoctorsListProps {
  userRole: UserRole;
}

const DoctorsList: React.FC<DoctorsListProps> = ({ userRole }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedSpecialty, setSelectedSpecialty] = useState('all');
  const [isNewAppointmentOpen, setIsNewAppointmentOpen] = useState(false);
  const [selectedDoctor, setSelectedDoctor] = useState<string>('');
  const [isAddDoctorOpen, setIsAddDoctorOpen] = useState(false);

  const mockDoctors: Doctor[] = [
    {
      id: '1',
      firstName: 'Dr. Paul',
      lastName: 'Mbarga',
      speciality: 'Cardiologie',
      email: 'paul.mbarga@medsecure.cm',
      phone: '+237 6 70 12 34 56',
      patients: 156,
      nextAvailability: '2024-06-27 14:30',
      status: 'available'
    },
    {
      id: '2',
      firstName: 'Dr. Marie',
      lastName: 'Nkomo',
      speciality: 'Pédiatrie',
      email: 'marie.nkomo@medsecure.cm',
      phone: '+237 6 70 12 34 57',
      patients: 89,
      nextAvailability: '2024-06-28 09:00',
      status: 'busy'
    },
    {
      id: '3',
      firstName: 'Dr. Jean',
      lastName: 'Fouda',
      speciality: 'Dermatologie',
      email: 'jean.fouda@medsecure.cm',
      phone: '+237 6 70 12 34 58',
      patients: 123,
      nextAvailability: '2024-06-27 16:00',
      status: 'available'
    }
  ];

  const specialties = ['all', 'Cardiologie', 'Pédiatrie', 'Dermatologie', 'Neurologie', 'Gynécologie'];

  const handleBookAppointment = (doctor: Doctor) => {
    setSelectedDoctor(`${doctor.firstName} ${doctor.lastName}`);
    setIsNewAppointmentOpen(true);
  };

  const filteredDoctors = mockDoctors.filter(doctor => {
    const matchesSearch = `${doctor.firstName} ${doctor.lastName}`.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesSpecialty = selectedSpecialty === 'all' || doctor.speciality === selectedSpecialty;
    return matchesSearch && matchesSpecialty;
  });

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">
            {userRole === 'admin' ? 'Gestion des médecins' : 'Médecins'}
          </h2>
          <p className="text-gray-600">
            {userRole === 'patient' ? 'Consultez la liste de nos médecins spécialisés' : 
             userRole === 'admin' ? 'Gérez les médecins de votre établissement' :
             'Liste des médecins de l\'établissement'}
          </p>
        </div>
        {userRole === 'admin' && (
          <Button 
            onClick={() => setIsAddDoctorOpen(true)}
            className="bg-medical-500 hover:bg-medical-600"
          >
            <Plus className="w-4 h-4 mr-2" />
            Ajouter un médecin
          </Button>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
          <Input
            placeholder="Rechercher un médecin..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>
        <select
          value={selectedSpecialty}
          onChange={(e) => setSelectedSpecialty(e.target.value)}
          className="px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-medical-500"
        >
          {specialties.map(specialty => (
            <option key={specialty} value={specialty}>
              {specialty === 'all' ? 'Toutes les spécialités' : specialty}
            </option>
          ))}
        </select>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredDoctors.map((doctor) => (
          <DoctorCard
            key={doctor.id}
            doctor={doctor}
            userRole={userRole}
            onBookAppointment={handleBookAppointment}
          />
        ))}
      </div>

      {filteredDoctors.length === 0 && (
        <div className="text-center py-12">
          <Stethoscope className="w-12 h-12 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">Aucun médecin trouvé</h3>
          <p className="text-gray-600">Essayez de modifier vos critères de recherche.</p>
        </div>
      )}

      <NewAppointmentModal
        isOpen={isNewAppointmentOpen}
        onClose={() => setIsNewAppointmentOpen(false)}
        doctorName={selectedDoctor}
        userRole={userRole}
      />

      <AddUserModal
        isOpen={isAddDoctorOpen}
        onClose={() => setIsAddDoctorOpen(false)}
      />
    </div>
  );
};

export default DoctorsList;
