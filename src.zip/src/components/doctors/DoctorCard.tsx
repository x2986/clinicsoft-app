
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  Stethoscope, 
  Phone, 
  Mail, 
  Calendar, 
  Users,
  Edit,
  Trash2
} from 'lucide-react';

interface Doctor {
  id: string;
  firstName: string;
  lastName: string;
  speciality: string;
  email: string;
  phone: string;
  patients: number;
  nextAvailability: string;
  status: 'available' | 'busy' | 'offline';
}

interface DoctorCardProps {
  doctor: Doctor;
  userRole: string;
  onBookAppointment: (doctor: Doctor) => void;
}

const DoctorCard: React.FC<DoctorCardProps> = ({ doctor, userRole, onBookAppointment }) => {
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'available': return 'bg-green-100 text-green-800';
      case 'busy': return 'bg-orange-100 text-orange-800';
      case 'offline': return 'bg-gray-100 text-gray-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'available': return 'Disponible';
      case 'busy': return 'Occupé';
      case 'offline': return 'Hors ligne';
      default: return 'Inconnu';
    }
  };

  return (
    <Card className="medical-card hover:shadow-lg transition-all">
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-medical-100 rounded-full flex items-center justify-center">
              <Stethoscope className="w-6 h-6 text-medical-600" />
            </div>
            <div>
              <CardTitle className="text-lg">{doctor.firstName} {doctor.lastName}</CardTitle>
              <p className="text-sm text-gray-600">{doctor.speciality}</p>
            </div>
          </div>
          <Badge className={getStatusColor(doctor.status)}>
            {getStatusText(doctor.status)}
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <div className="flex items-center gap-2 text-sm text-gray-600">
            <Mail className="w-4 h-4" />
            <span>{doctor.email}</span>
          </div>
          <div className="flex items-center gap-2 text-sm text-gray-600">
            <Phone className="w-4 h-4" />
            <span>{doctor.phone}</span>
          </div>
          <div className="flex items-center gap-2 text-sm text-gray-600">
            <Users className="w-4 h-4" />
            <span>{doctor.patients} patients</span>
          </div>
          <div className="flex items-center gap-2 text-sm text-gray-600">
            <Calendar className="w-4 h-4" />
            <span>Prochaine dispo: {new Date(doctor.nextAvailability).toLocaleString('fr-FR')}</span>
          </div>
        </div>

        <div className="flex gap-2 pt-3 border-t">
          {userRole === 'patient' && (
            <Button 
              size="sm" 
              className="flex-1 bg-medical-500 hover:bg-medical-600"
              onClick={() => onBookAppointment(doctor)}
            >
              <Calendar className="w-4 h-4 mr-1" />
              Prendre RDV
            </Button>
          )}
          {userRole === 'admin' && (
            <>
              <Button size="sm" variant="outline" className="flex-1">
                <Edit className="w-4 h-4 mr-1" />
                Modifier
              </Button>
              <Button size="sm" variant="outline" className="text-red-600 hover:text-red-700">
                <Trash2 className="w-4 h-4" />
              </Button>
            </>
          )}
          {(userRole === 'nurse' || userRole === 'doctor') && (
            <Button size="sm" variant="outline" className="flex-1">
              Voir profil
            </Button>
          )}
        </div>
      </CardContent>
    </Card>
  );
};

export default DoctorCard;
