
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { 
  MessageSquare, 
  Plus, 
  Search, 
  User, 
  Clock,
  Reply,
  Archive,
  Trash2
} from 'lucide-react';
import { UserRole } from '@/contexts/AuthContext';
import NewMessageModal from '@/components/modals/NewMessageModal';

interface MessagesCenterProps {
  userRole: UserRole;
}

const MessagesCenter: React.FC<MessagesCenterProps> = ({ userRole }) => {
  const [isNewMessageOpen, setIsNewMessageOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');

  const messages = [
    {
      id: '1',
      sender: 'Dr. Martin',
      recipient: 'Marie Dupont',
      subject: 'Résultats de vos analyses',
      preview: 'Bonjour, vos résultats d\'analyses sont disponibles...',
      date: '2024-06-26',
      time: '14:30',
      priority: 'normal',
      status: 'unread'
    },
    {
      id: '2',
      sender: 'Infirmière Sophie',
      recipient: 'Jean Martin',
      subject: 'Rappel rendez-vous',
      preview: 'N\'oubliez pas votre rendez-vous de demain à 9h...',
      date: '2024-06-25',
      time: '16:45',
      priority: 'high',
      status: 'read'
    }
  ];

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'urgent': return 'bg-red-100 text-red-800';
      case 'high': return 'bg-orange-100 text-orange-800';
      case 'normal': return 'bg-blue-100 text-blue-800';
      case 'low': return 'bg-gray-100 text-gray-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Messages</h2>
          <p className="text-gray-600">Centre de communication sécurisée</p>
        </div>
        <Button 
          onClick={() => setIsNewMessageOpen(true)}
          className="bg-medical-500 hover:bg-medical-600"
        >
          <Plus className="w-4 h-4 mr-2" />
          Nouveau message
        </Button>
      </div>

      <div className="relative">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
        <Input
          placeholder="Rechercher dans les messages..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="pl-10"
        />
      </div>

      <div className="grid gap-4">
        {messages.map((message) => (
          <Card key={message.id} className={`medical-card hover:shadow-md transition-shadow cursor-pointer ${message.status === 'unread' ? 'border-l-4 border-l-medical-500' : ''}`}>
            <CardContent className="p-6">
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2">
                    <div className="w-10 h-10 bg-medical-100 rounded-full flex items-center justify-center">
                      <MessageSquare className="w-5 h-5 text-medical-600" />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <h3 className={`font-medium ${message.status === 'unread' ? 'font-semibold text-gray-900' : 'text-gray-900'}`}>
                          {message.subject}
                        </h3>
                        <Badge className={getPriorityColor(message.priority)}>
                          {message.priority === 'urgent' ? 'Urgent' :
                           message.priority === 'high' ? 'Important' :
                           message.priority === 'normal' ? 'Normal' : 'Faible'}
                        </Badge>
                      </div>
                      <div className="flex items-center gap-4 text-sm text-gray-600">
                        <div className="flex items-center gap-1">
                          <User className="w-4 h-4" />
                          <span>{userRole === 'patient' ? `De: ${message.sender}` : `À: ${message.recipient}`}</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <Clock className="w-4 h-4" />
                          <span>{new Date(message.date).toLocaleDateString('fr-FR')} à {message.time}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                  <p className="text-gray-600 text-sm ml-13">{message.preview}</p>
                </div>
                
                <div className="flex gap-2 ml-4">
                  <Button size="sm" variant="outline">
                    <Reply className="w-4 h-4" />
                  </Button>
                  <Button size="sm" variant="outline">
                    <Archive className="w-4 h-4" />
                  </Button>
                  <Button size="sm" variant="outline" className="text-red-600 hover:text-red-700">
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <NewMessageModal
        isOpen={isNewMessageOpen}
        onClose={() => setIsNewMessageOpen(false)}
        userRole={userRole}
      />
    </div>
  );
};

export default MessagesCenter;
