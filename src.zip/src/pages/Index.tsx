import React, { useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { SidebarProvider, SidebarTrigger } from '@/components/ui/sidebar';
import Landing from '@/pages/Landing';
import LoginForm from '@/components/auth/LoginForm';
import RegisterForm from '@/components/auth/RegisterForm';
import AppSidebar from '@/components/layout/Sidebar';

// Import role-specific dashboards
import PatientDashboard from '@/components/dashboard/PatientDashboard';
import DoctorDashboard from '@/components/dashboard/DoctorDashboard';
import NurseDashboard from '@/components/dashboard/NurseDashboard';
import AdminDashboard from '@/components/dashboard/AdminDashboard';

import AppointmentCalendar from '@/components/appointments/AppointmentCalendar';
import PatientsList from '@/components/patients/PatientsList';
import MessagesCenter from '@/components/messages/MessagesCenter';
import MedicalRecords from '@/components/medical-records/MedicalRecords';
import ReportsSection from '@/components/reports/ReportsSection';
import PrescriptionsSection from '@/components/prescriptions/PrescriptionsSection';
import DoctorsList from '@/components/doctors/DoctorsList';
import ScheduleSection from '@/components/schedule/ScheduleSection';
import UsersManagement from '@/components/users/UsersManagement';
import SettingsSection from '@/components/settings/SettingsSection';
import PaymentsSection from '@/components/payments/PaymentsSection';

const Index = () => {
  const { user } = useAuth();
  const [currentPage, setCurrentPage] = useState('dashboard');
  const [authMode, setAuthMode] = useState<'landing' | 'login' | 'register'>('landing');

  // Si aucun utilisateur n'est connecté, afficher la landing page ou les formulaires
  if (!user) {
    if (authMode === 'login') {
      return <LoginForm />;
    }
    
    if (authMode === 'register') {
      return (
        <RegisterForm 
          onBack={() => setAuthMode('landing')}
          onSuccess={() => setAuthMode('login')}
        />
      );
    }
    
    return (
      <Landing 
        onLogin={() => setAuthMode('login')}
        onRegister={() => setAuthMode('register')}
      />
    );
  }

  const renderPageContent = () => {
    switch (currentPage) {
      case 'dashboard':
        // Return role-specific dashboard
        switch (user.role) {
          case 'patient':
            return <PatientDashboard />;
          case 'doctor':
            return <DoctorDashboard />;
          case 'nurse':
            return <NurseDashboard />;
          case 'admin':
            return <AdminDashboard />;
          default:
            return <PatientDashboard />;
        }
      
      case 'appointments':
        return <AppointmentCalendar userRole={user.role} />;
      
      case 'patients':
        return <PatientsList />;
      
      case 'messages':
        return <MessagesCenter userRole={user.role} />;
      
      case 'medical-records':
        return <MedicalRecords userRole={user.role} />;
      
      case 'reports':
        return <ReportsSection userRole={user.role} />;
      
      case 'prescriptions':
        return <PrescriptionsSection userRole={user.role} />;
      
      case 'doctors':
        return <DoctorsList userRole={user.role} />;
      
      case 'schedule':
        return <ScheduleSection userRole={user.role} />;
      
      case 'users':
        return <UsersManagement />;
      
      case 'settings':
        return <SettingsSection />;
      
      case 'payments':
        return <PaymentsSection userRole={user.role} />;
      
      default:
        return (
          <div className="space-y-6">
            <h2 className="text-2xl font-bold text-gray-900 capitalize">
              {currentPage.replace('-', ' ')}
            </h2>
            <div className="medical-card p-6">
              <p className="text-gray-600">Cette fonctionnalité est maintenant disponible !</p>
            </div>
          </div>
        );
    }
  };

  return (
    <SidebarProvider>
      <div className="min-h-screen flex w-full bg-gray-50">
        <AppSidebar currentPage={currentPage} onPageChange={setCurrentPage} />
        <main className="flex-1 flex flex-col">
          <header className="bg-white border-b border-gray-200 px-6 py-4">
            <div className="flex items-center gap-4">
              <SidebarTrigger />
              <div className="flex-1" />
              <div className="text-sm text-gray-500">
                {new Date().toLocaleDateString('fr-FR', {
                  weekday: 'long',
                  year: 'numeric',
                  month: 'long',
                  day: 'numeric'
                })}
              </div>
            </div>
          </header>
          
          <div className="flex-1 p-6">
            {renderPageContent()}
          </div>
        </main>
      </div>
    </SidebarProvider>
  );
};

export default Index;
