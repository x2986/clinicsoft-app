
import React from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { 
  Heart, 
  Shield, 
  Calendar, 
  Users, 
  FileText, 
  MessageSquare,
  Stethoscope,
  Clock,
  CheckCircle,
  Phone,
  Mail,
  MapPin,
  Star,
  ArrowRight,
  Activity,
  UserCheck,
  Award
} from 'lucide-react';

interface LandingProps {
  onLogin: () => void;
  onRegister: () => void;
}

const Landing: React.FC<LandingProps> = ({ onLogin, onRegister }) => {
  const features = [
    {
      icon: Calendar,
      title: "Gestion des rendez-vous",
      description: "Planifiez et gérez vos consultations en ligne avec nos médecins spécialisés",
      color: "bg-blue-100 text-blue-600"
    },
    {
      icon: FileText,
      title: "Dossier médical numérique",
      description: "Accès sécurisé à votre historique médical complet, disponible 24h/24",
      color: "bg-green-100 text-green-600"
    },
    {
      icon: MessageSquare,
      title: "Communication sécurisée",
      description: "Échangez directement avec votre équipe médicale via notre messagerie cryptée",
      color: "bg-purple-100 text-purple-600"
    },
    {
      icon: Shield,
      title: "Sécurité maximale",
      description: "Protection de vos données médicales avec un chiffrement de niveau hospitalier",
      color: "bg-red-100 text-red-600"
    },
    {
      icon: Activity,
      title: "Suivi en temps réel",
      description: "Surveillez vos paramètres vitaux et recevez des alertes personnalisées",
      color: "bg-orange-100 text-orange-600"
    },
    {
      icon: UserCheck,
      title: "Équipe qualifiée",
      description: "Médecins certifiés et personnel médical expérimenté à votre service",
      color: "bg-indigo-100 text-indigo-600"
    }
  ];

  const specialties = [
    { name: "Médecine générale", patients: "500+" },
    { name: "Cardiologie", patients: "200+" },
    { name: "Dermatologie", patients: "150+" },
    { name: "Pédiatrie", patients: "300+" },
    { name: "Gynécologie", patients: "180+" },
    { name: "Orthopédie", patients: "120+" },
    { name: "Ophtalmologie", patients: "100+" },
    { name: "Radiologie", patients: "250+" }
  ];

  const stats = [
    { number: "2,500+", label: "Patients actifs", icon: Users },
    { number: "50+", label: "Médecins qualifiés", icon: Stethoscope },
    { number: "10,000+", label: "Consultations réalisées", icon: Calendar },
    { number: "99.9%", label: "Disponibilité", icon: Clock }
  ];

  const testimonials = [
    {
      name: "Dr. Marie Ngono",
      role: "Cardiologue",
      message: "MedSecure a révolutionné ma pratique médicale. La gestion des dossiers patients n'a jamais été aussi simple.",
      rating: 5
    },
    {
      name: "Jean-Paul Messi",
      role: "Patient",
      message: "Excellent service ! Je peux consulter mes résultats et communiquer avec mon médecin facilement.",
      rating: 5
    },
    {
      name: "Infirmière Claire Biya",
      role: "Service de pédiatrie",
      message: "Interface intuitive qui nous fait gagner un temps précieux dans nos soins quotidiens.",
      rating: 5
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-medical-50 via-white to-medical-50">
      {/* Header */}
      <header className="bg-white/95 backdrop-blur-sm border-b border-medical-100 sticky top-0 z-50 shadow-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-gradient-to-br from-medical-500 to-medical-600 rounded-xl flex items-center justify-center shadow-lg">
                <Heart className="w-7 h-7 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-gray-900">ClinicSoft</h1>
                <p className="text-xs text-gray-600">Santé numérique - Cameroun</p>
              </div>
            </div>
            <div className="flex gap-3">
              <Button variant="outline" onClick={onLogin} className="hover:bg-medical-50">
                Se connecter
              </Button>
              <Button onClick={onRegister} className="bg-gradient-to-r from-medical-500 to-medical-600 hover:from-medical-600 hover:to-medical-700 shadow-lg">
                Créer un compte
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-20 px-4 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-medical-500/5 to-medical-600/5"></div>
        <div className="container mx-auto text-center relative">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-6xl font-bold text-gray-900 mb-6 leading-tight">
              Votre santé, <span className="text-transparent bg-clip-text bg-gradient-to-r from-medical-500 to-medical-600">notre mission</span>
            </h2>
            <p className="text-xl text-gray-600 mb-10 max-w-2xl mx-auto leading-relaxed">
              Révolutionnez votre expérience médicale avec la première plateforme de santé numérique 
              du Cameroun. Consultations, dossiers médicaux et communication sécurisée en un seul endroit.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
              <Button 
                size="lg" 
                onClick={onRegister}
                className="bg-gradient-to-r from-medical-500 to-medical-600 hover:from-medical-600 hover:to-medical-700 text-lg px-8 py-4 shadow-xl hover:shadow-2xl transition-all duration-300"
              >
                Commencer maintenant
                <ArrowRight className="ml-2 w-5 h-5" />
              </Button>
              <Button 
                size="lg" 
                variant="outline" 
                className="text-lg px-8 py-4 hover:bg-medical-50 border-2"
              >
                Découvrir la plateforme
              </Button>
            </div>
            
            {/* Stats */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mt-16">
              {stats.map((stat, index) => (
                <div key={index} className="text-center">
                  <div className="w-16 h-16 bg-white rounded-full flex items-center justify-center mx-auto mb-3 shadow-lg">
                    <stat.icon className="w-8 h-8 text-medical-500" />
                  </div>
                  <div className="text-3xl font-bold text-gray-900">{stat.number}</div>
                  <div className="text-sm text-gray-600">{stat.label}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 px-4 bg-white">
        <div className="container mx-auto">
          <div className="text-center mb-16">
            <h3 className="text-4xl font-bold text-gray-900 mb-6">
              Une plateforme complète pour votre santé
            </h3>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Découvrez toutes les fonctionnalités qui transforment votre expérience médicale
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <Card key={index} className="hover:shadow-xl transition-all duration-300 border-0 shadow-md hover:-translate-y-2 group">
                <CardHeader className="pb-4">
                  <div className={`w-16 h-16 ${feature.color} rounded-2xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300`}>
                    <feature.icon className="w-8 h-8" />
                  </div>
                  <CardTitle className="text-xl">{feature.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600 leading-relaxed">{feature.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Specialties Section */}
      <section className="py-20 px-4 bg-gradient-to-br from-medical-50 to-medical-100">
        <div className="container mx-auto">
          <div className="text-center mb-16">
            <h3 className="text-4xl font-bold text-gray-900 mb-6">
              Nos spécialités médicales
            </h3>
            <p className="text-xl text-gray-600">
              Une équipe de spécialistes expérimentés pour tous vos besoins de santé
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {specialties.map((specialty, index) => (
              <div 
                key={index}
                className="bg-white p-6 rounded-2xl shadow-md hover:shadow-xl transition-all duration-300 hover:-translate-y-1 group"
              >
                <div className="flex items-center justify-between mb-2">
                  <h4 className="font-semibold text-gray-800 group-hover:text-medical-600 transition-colors">
                    {specialty.name}
                  </h4>
                  <Award className="w-5 h-5 text-medical-500" />
                </div>
                <p className="text-sm text-gray-500">{specialty.patients} patients suivis</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-20 px-4 bg-white">
        <div className="container mx-auto">
          <div className="text-center mb-16">
            <h3 className="text-4xl font-bold text-gray-900 mb-6">
              Ce que disent nos utilisateurs
            </h3>
            <p className="text-xl text-gray-600">
              La confiance de nos patients et professionnels de santé
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <Card key={index} className="border-0 shadow-lg hover:shadow-xl transition-all duration-300">
                <CardContent className="p-6">
                  <div className="flex mb-4">
                    {[...Array(testimonial.rating)].map((_, i) => (
                      <Star key={i} className="w-5 h-5 text-yellow-400 fill-current" />
                    ))}
                  </div>
                  <p className="text-gray-600 mb-4 italic">"{testimonial.message}"</p>
                  <div>
                    <p className="font-semibold text-gray-900">{testimonial.name}</p>
                    <p className="text-sm text-gray-500">{testimonial.role}</p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4 bg-gradient-to-r from-medical-500 to-medical-600 relative overflow-hidden">
        <div className="absolute inset-0 bg-black/10"></div>
        <div className="container mx-auto text-center relative">
          <h3 className="text-4xl font-bold text-white mb-6">
            Prêt à transformer votre expérience médicale ?
          </h3>
          <p className="text-medical-100 text-xl mb-10 max-w-2xl mx-auto leading-relaxed">
            Rejoignez la révolution numérique de la santé au Cameroun. 
            Des milliers de patients nous font déjà confiance.
          </p>
          <Button 
            size="lg" 
            onClick={onRegister}
            className="bg-white text-medical-600 hover:bg-gray-100 text-xl px-10 py-4 shadow-2xl hover:shadow-3xl transition-all duration-300"
          >
            Créer mon compte maintenant
            <ArrowRight className="ml-2 w-6 h-6" />
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-16 px-4">
        <div className="container mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center gap-3 mb-6">
                <div className="w-10 h-10 bg-gradient-to-br from-medical-400 to-medical-500 rounded-lg flex items-center justify-center">
                  <Heart className="w-6 h-6 text-white" />
                </div>
                <span className="text-2xl font-bold">ClinicSoft</span>
              </div>
              <p className="text-gray-400 leading-relaxed">
                La première plateforme de santé numérique du Cameroun. 
                Innovation, sécurité et excellence médicale au service de votre bien-être.
              </p>
            </div>
            
            <div>
              <h4 className="font-semibold mb-6 text-lg">Services</h4>
              <ul className="space-y-3 text-gray-400">
                <li className="hover:text-white transition-colors cursor-pointer">Téléconsultations</li>
                <li className="hover:text-white transition-colors cursor-pointer">Dossiers médicaux électroniques</li>
                <li className="hover:text-white transition-colors cursor-pointer">Gestion des rendez-vous</li>
                <li className="hover:text-white transition-colors cursor-pointer">Messagerie médicale sécurisée</li>
                <li className="hover:text-white transition-colors cursor-pointer">Suivi des paramètres vitaux</li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-semibold mb-6 text-lg">Spécialités</h4>
              <ul className="space-y-3 text-gray-400">
                <li className="hover:text-white transition-colors cursor-pointer">Médecine générale</li>
                <li className="hover:text-white transition-colors cursor-pointer">Cardiologie</li>
                <li className="hover:text-white transition-colors cursor-pointer">Dermatologie</li>
                <li className="hover:text-white transition-colors cursor-pointer">Pédiatrie</li>
                <li className="hover:text-white transition-colors cursor-pointer">Gynécologie-Obstétrique</li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-semibold mb-6 text-lg">Contact</h4>
              <div className="space-y-4 text-gray-400">
                <div className="flex items-center gap-3 hover:text-white transition-colors">
                  <Phone className="w-5 h-5 text-medical-400" />
                  <span>+237 6 98 76 54 32</span>
                </div>
                <div className="flex items-center gap-3 hover:text-white transition-colors">
                  <Mail className="w-5 h-5 text-medical-400" />
                  <span>contact@medsecure.cm</span>
                </div>
                <div className="flex items-start gap-3 hover:text-white transition-colors">
                  <MapPin className="w-5 h-5 text-medical-400 mt-1" />
                  <div>
                    <p>Avenue Monseigneur Vogt</p>
                    <p>Yaoundé, Région du Centre</p>
                    <p>Cameroun</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          <div className="border-t border-gray-800 mt-12 pt-8 flex flex-col md:flex-row justify-between items-center">
            <p className="text-gray-400">&copy; 2025 ClinicSoft Cameroun. Tous droits réservés.</p>
            <div className="flex gap-6 mt-4 md:mt-0">
              <a href="#" className="text-gray-400 hover:text-white transition-colors">Politique de confidentialité</a>
              <a href="#" className="text-gray-400 hover:text-white transition-colors">Conditions d'utilisation</a>
              <a href="#" className="text-gray-400 hover:text-white transition-colors">Support</a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Landing;
