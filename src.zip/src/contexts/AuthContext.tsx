
import React, { createContext, useContext, useState, useEffect } from 'react';

export type UserRole = 'patient' | 'doctor' | 'nurse' | 'admin';

export interface User {
  id: string;
  email: string;
  firstName: string;
  lastName: string;
  role: UserRole;
  speciality?: string;
  phone?: string;
  avatar?: string;
}

interface AuthContextType {
  user: User | null;
  login: (email: string, password: string) => Promise<void>;
  logout: () => void;
  isLoading: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Simulate checking for existing session
    const storedUser = localStorage.getItem('medicalUser');
    if (storedUser) {
      setUser(JSON.parse(storedUser));
    }
    setIsLoading(false);
  }, []);

  const login = async (email: string, password: string) => {
    setIsLoading(true);
    
    // Simulate API call - in real app, this would be an actual API request
    await new Promise(resolve => setTimeout(resolve, 1000));

    // Mock user data based on email for demo purposes
    let mockUser: User;
    
    if (email.includes('doctor') || email.includes('medecin')) {
      mockUser = {
        id: '1',
        email,
        firstName: 'Dr. Sarah',
        lastName: 'Martin',
        role: 'doctor',
        speciality: 'Cardiologie',
        phone: '+33 1 23 45 67 89',
      };
    } else if (email.includes('nurse') || email.includes('infirmier')) {
      mockUser = {
        id: '2',
        email,
        firstName: 'Marie',
        lastName: 'Dubois',
        role: 'nurse',
        phone: '+33 1 23 45 67 90',
      };
    } else if (email.includes('admin')) {
      mockUser = {
        id: '3',
        email,
        firstName: 'Jean',
        lastName: 'Administrateur',
        role: 'admin',
        phone: '+33 1 23 45 67 91',
      };
    } else {
      mockUser = {
        id: '4',
        email,
        firstName: 'Pierre',
        lastName: 'Dupont',
        role: 'patient',
        phone: '+33 1 23 45 67 92',
      };
    }

    setUser(mockUser);
    localStorage.setItem('medicalUser', JSON.stringify(mockUser));
    setIsLoading(false);
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('medicalUser');
  };

  return (
    <AuthContext.Provider value={{ user, login, logout, isLoading }}>
      {children}
    </AuthContext.Provider>
  );
};
